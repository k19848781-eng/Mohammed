package com.mohammed.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Collections;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final String PLAYLIST_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.m3u";
    static final String USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20";
    static final String CODE_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/code.txt";
    static final String DAT_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.dat";
    static final String DEFAULT_CODE = "1010";
    boolean checking = false;
    boolean blockedNow = false;
    TextView blocker;

    // Network capture / sniffing apps. If any is installed, the app will not play.
    static final String[] SNIFFERS = {
            "com.guoshi.httpcanary", "com.guoshi.httpcanary.premium",
            "app.greyshirts.sslcapture", "com.emanuelef.remote_capture",
            "com.minhui.networkcapture", "com.minhui.networkcapture.pro",
            "com.reqable.android"
    };
    final Runnable guardLoop = new Runnable() {
        @Override public void run() { guard(); h.postDelayed(this, 4000); }
    };

    SharedPreferences prefs;
    ExoPlayer player;
    PlayerView playerView;
    TextView osd, status, dots, msg;
    View guide, act, tap;
    ListView list;
    ArrayAdapter<String> adapter;

    final List<String> names = new ArrayList<>();
    final List<String> urls = new ArrayList<>();
    final List<String> labels = new ArrayList<>();
    final List<Button> keys = new ArrayList<>();

    int current = -1;
    int retries = 0;
    String code = "";
    boolean swallowCenterUp = false;
    String numBuf = "";
    final Runnable numGo = this::goNumber;
    File pendingApk = null;
    static final String RELEASE_API = "https://api.github.com/repos/k19848781-eng/Mohammed/releases/latest";
    boolean syncPending = false;
    // Moving text (news ticker) at the bottom of your own channels
    static final String TICKER_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/ticker.txt";
    // Your logo in the top-right corner of your own channels (no need to add it in CapCut)
    static final String LOGO_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/logo.png";
    ImageView channelLogo;
    android.widget.LinearLayout logoBox;
    FrameLayout tickerBar;
    TickerView tickerText;
    String tickerMsg = "";
    final Runnable tickerRefresh = new Runnable() {
        @Override public void run() {
            fetchTicker();
            fetchLogo();
            h.postDelayed(this, 10 * 60 * 1000);
        }
    };
    SimpleCache mediaCache;                       // stores parts of Archive.org videos on the device
    ProgressiveMediaSource.Factory archiveFactory; // player source for Archive.org videos
    boolean archiveRetried = false; // Archive.org channels: jump to the 'live' moment once ready

    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable hideOsd = () -> osd.setVisibility(View.GONE);
    final Runnable hideGuide = this::closeGuide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        prefs = getSharedPreferences("mtv", MODE_PRIVATE);
        playerView = findViewById(R.id.player);
        setupTicker();
        osd = findViewById(R.id.osd);
        status = findViewById(R.id.status);
        guide = findViewById(R.id.guide);
        list = findViewById(R.id.list);
        act = findViewById(R.id.act);
        dots = findViewById(R.id.dots);
        msg = findViewById(R.id.msg);
        tap = findViewById(R.id.tap);
        blocker = findViewById(R.id.blocker);

        // Player that behaves like VLC: any link, http or https, with a VLC user agent
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(USER_AGENT)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(this, http);
        // Start playing after 1 second of video is loaded (default was 2.5 seconds)
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15000, 50000, 1000, 2000)
                .build();
        // Archive.org videos play directly (no device cache), like the version you tested as fast
        mediaCache = null;
        archiveFactory = null;
        // Forget any saved direct server links from the previous version
        SharedPreferences.Editor ed = prefs.edit();
        for (String k : prefs.getAll().keySet()) if (k.startsWith("fin_")) ed.remove(k);
        ed.apply();
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSource))
                .setLoadControl(loadControl)
                .build();
        playerView.setPlayer(player);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setKeepScreenOn(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    retries = 0;
                    updateTicker();
                    if (syncPending) {
                        syncPending = false;
                        long d = player.getDuration();
                        if (d != C.TIME_UNSET && d > 0) {
                            // Remember the length, so next time the channel opens directly at the right moment
                            if (current >= 0 && current < urls.size()) {
                                prefs.edit().putLong(durKey(urls.get(current)), d).apply();
                            }
                            // Same moment for everyone, based on the clock, like real live TV
                            player.seekTo(System.currentTimeMillis() % d);
                        }
                    }
                    status.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    showStatus("Loading…");
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (current >= 0 && current < urls.size()) {
                    String u = urls.get(current);
                    if (isLoopChannel(u) && !archiveRetried && prefs.contains(finalKey(u))) {
                        // The saved direct server link stopped working: forget it and try the normal link
                        archiveRetried = true;
                        prefs.edit().remove(finalKey(u)).apply();
                        tune(current);
                        return;
                    }
                }
                showStatus("This channel isn't available right now. Try another one.");
            }
        });

        adapter = new ArrayAdapter<>(this, R.layout.item_channel, labels);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            tune(position);
            closeGuide();
        });
        list.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView v, int s) { resetGuideTimer(); }
            @Override public void onScroll(android.widget.AbsListView v, int a, int b, int c) { }
        });

        tap.setOnClickListener(v -> {
            if (guide.getVisibility() == View.VISIBLE) closeGuide();
            else openGuide();
        });

        buildKeypad();

        guard();
        if (prefs.getBoolean("activated", false)) {
            if (!blockedNow) start();
        } else {
            act.setVisibility(View.VISIBLE);
            drawCode();
            if (!keys.isEmpty()) keys.get(0).requestFocus();
        }
        h.postDelayed(this::checkUpdate, 6000);
        h.postDelayed(tickerRefresh, 2000);
    }

    // ---------- Activation ----------

    void buildKeypad() {
        GridLayout pad = findViewById(R.id.pad);
        String[] labelsArr = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK"};
        int size = dp(76);
        int gap = dp(6);
        for (String k : labelsArr) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setGravity(Gravity.CENTER);
            b.setFocusable(true);
            b.setBackgroundResource(R.drawable.key_bg);
            b.setTextColor(k.equals("OK") ? 0xFFF5B83D : 0xFFEAF1F8);
            b.setStateListAnimator(null);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = (int) (size * 1.25);
            lp.height = size;
            lp.setMargins(gap, gap, gap, gap);
            b.setLayoutParams(lp);
            final String key = k.equals("⌫") ? "del" : k.equals("OK") ? "ok" : k;
            b.setOnClickListener(v -> press(key));
            pad.addView(b);
            keys.add(b);
        }
    }

    void press(String k) {
        msg.setText("");
        if (k.equals("del")) {
            if (code.length() > 0) code = code.substring(0, code.length() - 1);
        } else if (k.equals("ok")) {
            check();
            return;
        } else if (code.length() < 4) {
            code += k;
            if (code.length() == 4) {
                drawCode();
                h.postDelayed(this::check, 250);
                return;
            }
        }
        drawCode();
    }

    void check() {
        if (checking) return;
        checking = true;
        final String entered = code;
        msg.setText("Checking…");
        new Thread(() -> {
            // The activation code lives in code.txt on GitHub, so it can be changed any time
            long t = System.currentTimeMillis();
            String remote = codeFrom(decrypt(download(DAT_URL + "?t=" + t)));
            if (remote == null) {
                remote = download(CODE_URL + "?t=" + t);
                if (remote != null && remote.contains("<")) remote = null;
            }
            if (remote != null) remote = remote.trim();
            final String fetched = (remote != null && !remote.isEmpty() && remote.length() <= 20) ? remote : null;
            h.post(() -> {
                checking = false;
                if (fetched != null) prefs.edit().putString("lastCode", fetched).apply();
                String expected = fetched != null ? fetched : prefs.getString("lastCode", DEFAULT_CODE);
                if (entered.equals(expected)) {
                    prefs.edit().putBoolean("activated", true).apply();
                    msg.setText("");
                    act.setVisibility(View.GONE);
                    start();
                } else {
                    msg.setText(fetched == null ? "No internet. Connect and try again." : "Wrong code. Try again.");
                    code = "";
                    drawCode();
                }
            });
        }).start();
    }

    void drawCode() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(i < code.length() ? "●" : "○");
            if (i < 3) sb.append(' ');
        }
        dots.setText(sb.toString());
    }

    // ---------- Playlist ----------

    void start() {
        if (blockedNow) return;
        String cached = decrypt(prefs.getString("dat", null));
        if (cached == null) cached = prefs.getString("playlist", null);
        if (cached != null) {
            parse(cached);
            if (!urls.isEmpty()) tune(0);
        }
        if (urls.isEmpty()) showStatus("Loading channels…");
        new Thread(() -> {
            long t = System.currentTimeMillis();
            String enc = download(DAT_URL + "?t=" + t);
            String text = decrypt(enc);
            boolean fromDat = text != null;
            if (!fromDat) text = download(PLAYLIST_URL + "?t=" + t);
            final String result = text;
            if (result == null || !result.contains("#EXT")) {
                h.post(() -> { if (urls.isEmpty()) showStatus("Can't load channels. Check the internet."); });
                return;
            }
            h.post(() -> {
                if (fromDat) prefs.edit().putString("dat", enc.trim()).remove("playlist").apply();
                else prefs.edit().putString("playlist", result).apply();
                parse(result);
                if (current < 0 || current >= urls.size()) {
                    if (!urls.isEmpty()) tune(0);
                }
            });
        }).start();
    }

    // Playlist is published encrypted (playlist.dat); only this app can read it
    String decrypt(String b64) {
        if (b64 == null) return null;
        try {
            byte[] raw = android.util.Base64.decode(b64.trim(), android.util.Base64.DEFAULT);
            if (raw.length <= 256) return null;
        String[] p = {
                "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDBAnZiRA9gLSUdXm6qsCJMQdiD",
                "iA/2vvAh+Hp7QXlamaWZYf1vpBofGrrp7OsqIDS8BgvcvZXWT0vD7t/6RFRu8ABE8UGQF5FCByzV",
                "ZPH18D4OhP00SQTnqnumYRyXRGF8x1nLuRa/X4r17cr5i+gxGbafipwq+N8edSPBusflaYgb07Qu",
                "Ew2Ogah42MDT7BmAroeua7LQJaGoGlVKOyNeFhKwZEsZJMAnVFv4tjxdpZzGf+JhBP/edJn1VO4z",
                "flzxmHViSlN3j3XqJYgot3xKUJb7v1Nc1rXEkQ1qWW8azOP0lb1m40m2OVlwrwq+SXe8DpyrUQNW",
                "hDiNtyV1O6mhAgMBAAECggEACvKyP0JR7rQ622jNjVcst9+Bifr2IFp97ahd/rc03HC0E/Bq7znr",
                "TSW/kdixcXAWm656Xmbe3KNedmaKrAQTl8AbfM2kSNmMYNbeOjvFzYv3Qiy1HeHRMlihV0uBgxtS",
                "7hBzAY89+QSg8dCfa4KuDNhy+2dh8r5PjidJ/CGFmJe3oNDkI3nu5Lv1RVu52LLCUgTEKbFFFjJT",
                "T7sdiCww9HZ3ocsXmqQub5ZKV0T21aIYbjUyZIbSkfdOAyVRwHITFLP9/OM+PN1uzbLMqkCxnQfe",
                "l+XwO8mG/6Ke7NEKYyu6nW8tbOOVVP5DZvhqxBvkwJqHREyAZeDk7C8bnOc8MQKBgQD8Fycv1CFw",
                "oRnjhPI2WlUeXrYVXmqRGlLijq+3iRFNb3iabXHBKe0CrcYH0jsqoyc6daKQgJLn5FIhN/sDcqhP",
                "V5neABpgAQE++xpgMKqNXQe3loG5OKvsEUF7LLIyABo1Lsa80TBHqhvuMNZrY9kITjlbPJnPM3gp",
                "Bz6SA2qjsQKBgQDEAL9Njp/mshjn8/K3Qmi0+8mmLLuvGauLc4OAVXToFIoAGKYql6zocwur74pJ",
                "FavGPTZNoWcJ3IpCwNCOauwYutnPDCACQvW5R/vY8o4s9nh9AP9Sew5tFWD2yrUoJXIdhqKiC9ca",
                "imf2qIu5HqmNAsoYdP501tUjOC/gowSQ8QKBgE4qW7M/4nKK8X0TvwrNbbEyCuGLWh3N/L9VIPUW",
                "4i+RjeLMZsZPWrdG7K2GKWRqHILK8PI/e829hR3ZvtJt3fRkJEiq3YLBLQK7V41V6bxViUwKtgSZ",
                "pu1W2Gf6DvLkBzxQWb04W/EMtQZhTEsWNbiWkMBShRqzSeHm5ibeOlWxAoGAMVve0TExo28GRqNw",
                "ZCYdKDagOXDacuYMBTo5y3+5yRgjCJMshV1c9czDC7FvKaiDcZDItBQJVrprNxRHcRYMDs4/O5za",
                "Ere6Gca+7Ytnsnr/LLurkKHcqCvSF1RE+q8zZawaGKTSrqRcOgmH5j6KhDBHpJER42qWkh/8Lp3e",
                "8IECgYBalrIxJ1LP3rrWTmrIO1dMe/nSJv77MGxdIy0Y8evv29+v7/nuBoxV+EaeK7aqpB2VVPD7",
                "ivf+JGN3or3XsQZi7TpgErL5FLIYTzHuoZXVkex+EGrxRkyLMIJbgoLaAC0hRm78jSV6Vd3ZCkUr",
                "k0xcwLudM+1LX47tchJH8dqCvQ=="
        };
            StringBuilder sb = new StringBuilder();
            for (String x : p) sb.append(x);
            PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(
                    new PKCS8EncodedKeySpec(android.util.Base64.decode(sb.toString(), android.util.Base64.DEFAULT)));
            Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsa.init(Cipher.DECRYPT_MODE, pk);
            byte[] kv = rsa.doFinal(Arrays.copyOfRange(raw, 0, 256));
            if (kv.length != 48) return null;
            Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
            aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(Arrays.copyOfRange(kv, 0, 32), "AES"),
                    new IvParameterSpec(Arrays.copyOfRange(kv, 32, 48)));
            return new String(aes.doFinal(Arrays.copyOfRange(raw, 256, raw.length)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    static String codeFrom(String text) {
        if (text == null) return null;
        for (String line : text.split("\n")) {
            line = line.trim();
            if (line.startsWith("#CODE:")) {
                String c = line.substring(6).trim();
                return c.isEmpty() ? null : c;
            }
        }
        return null;
    }

    String download(String address) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    void parse(String text) {
        names.clear();
        urls.clear();
        labels.clear();
        String name = null;
        for (String raw : text.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                int comma = line.lastIndexOf(',');
                name = comma >= 0 ? line.substring(comma + 1).trim() : null;
            } else if (!line.startsWith("#")) {
                String n = (name == null || name.isEmpty()) ? "Channel " + (urls.size() + 1) : name;
                names.add(n);
                urls.add(line);
                labels.add((urls.size()) + "    " + n);
                name = null;
            }
        }
        adapter.notifyDataSetChanged();
        if (current >= 0 && current < urls.size()) list.setItemChecked(current, true);
    }

    // ---------- Playback ----------

    void tune(int i) {
        if (blockedNow) return;
        int n = urls.size();
        if (n == 0) return;
        current = ((i % n) + n) % n;
        retries = 0;
        String url = urls.get(current);
        if (!isLoopChannel(url) || !prefs.contains(finalKey(url))) archiveRetried = false;
        osd.setText((current + 1) + "   " + names.get(current));
        osd.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideOsd);
        h.postDelayed(hideOsd, 3500);
        list.setItemChecked(current, true);

        MediaItem.Builder b = new MediaItem.Builder().setUri(url);
        String low = url.toLowerCase();
        if (low.contains(".m3u8")) {
            b.setMimeType(MimeTypes.APPLICATION_M3U8);
        }
        boolean loopChannel = isLoopChannel(url);
        // Live feature turned off: your own channels start from the beginning (fast) and repeat at the end
        long knownDur = 0;
        syncPending = false;
        player.setRepeatMode(loopChannel ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
        showStatus("Loading…");
        if (loopChannel && archiveFactory != null) {
            // Use the saved direct server link (skips Archive.org's redirect) and the device cache
            String direct = prefs.getString(finalKey(url), url);
            MediaItem item = new MediaItem.Builder().setUri(direct).setCustomCacheKey(url).build();
            MediaSource ms = archiveFactory.createMediaSource(item);
            if (knownDur > 0) player.setMediaSource(ms, System.currentTimeMillis() % knownDur);
            else player.setMediaSource(ms);
        } else if (knownDur > 0) {
            // Open directly at the live moment: only one load, no jump afterwards
            player.setMediaItem(b.build(), System.currentTimeMillis() % knownDur);
        } else {
            player.setMediaItem(b.build());
        }
        player.prepare();
        player.play();
        updateTicker();
    }

    // ---------- News ticker ----------

    float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    void setupTicker() {
        ViewGroup root = (ViewGroup) playerView.getParent();
        tickerBar = new FrameLayout(this);
        tickerBar.setBackgroundColor(Color.parseColor("#CC0E1A2B"));
        tickerBar.setClipChildren(true);
        tickerText = new TickerView(this, dp(20 * getResources().getConfiguration().fontScale), dp(6), dp(110));
        tickerBar.addView(tickerText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        // Placed just above the video, below the channel list and other screens
        root.addView(tickerBar, root.indexOfChild(playerView) + 1, lp);

        channelLogo = new ImageView(this);
        channelLogo.setAdjustViewBounds(true);
        channelLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        channelLogo.setAlpha(0.9f);
        Bitmap saved = BitmapFactory.decodeFile(new File(getFilesDir(), "logo.png").getPath());
        if (saved != null) channelLogo.setImageBitmap(saved);
        else channelLogo.setImageResource(R.drawable.channel_logo);
        // Logo only, in the top-right corner (same as the first version)
        logoBox = new android.widget.LinearLayout(this);
        int size = (int) Math.min(getResources().getDisplayMetrics().heightPixels * 0.14f, dp(110));
        logoBox.addView(channelLogo, new android.widget.LinearLayout.LayoutParams(size, size));
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        llp.setMargins(0, (int) dp(20), (int) dp(24), 0);
        root.addView(logoBox, root.indexOfChild(tickerBar) + 1, llp);
        logoBox.setVisibility(View.GONE);
        tickerBar.setVisibility(View.GONE);
    }

    // If you upload logo.png to GitHub, the app uses it instead of the built-in logo
    void fetchLogo() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(LOGO_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                Bitmap bmp = BitmapFactory.decodeStream(c.getInputStream());
                if (bmp == null) return;
                try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "logo.png"))) {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                }
                runOnUiThread(() -> channelLogo.setImageBitmap(bmp));
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    void fetchTicker() {
        new Thread(() -> {
            String t = download(TICKER_URL + "?t=" + System.currentTimeMillis());
            if (t == null) return; // no internet or no file: keep what we have
            String msg = t.replace('\n', ' ').replace('\r', ' ').trim();
            if (msg.contains("<")) msg = "";
            final String m = msg;
            runOnUiThread(() -> {
                if (!m.equals(tickerMsg)) {
                    tickerMsg = m;
                    tickerText.setText(m);
                }
                updateTicker();
            });
        }).start();
    }

    void updateTicker() {
        if (tickerBar == null) return;
        boolean own = current >= 0 && current < urls.size() && isLoopChannel(urls.get(current));
        // Logo and moving text appear only after the video has started, so they never slow down loading
        boolean playing = player != null && player.getPlaybackState() == Player.STATE_READY;
        boolean showLogo = own && playing && !blockedNow;
        if (logoBox != null) logoBox.setVisibility(showLogo ? View.VISIBLE : View.GONE);
        boolean show = showLogo && !tickerMsg.isEmpty();
        tickerBar.setVisibility(show ? View.VISIBLE : View.GONE);
        tickerText.setRunning(show);
    }

    // Light-weight moving text: draws only the text, no big animated view
    static class TickerView extends View {
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final float pad, speed;
        String text = "";
        float textW, x;
        boolean rtl, running, needReset = true;
        long last;

        TickerView(android.content.Context c, float textPx, float pad, float speedPxPerSec) {
            super(c);
            this.pad = pad;
            this.speed = speedPxPerSec;
            p.setColor(Color.WHITE);
            p.setTextSize(textPx);
            p.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void setText(String t) {
            text = t == null ? "" : t;
            textW = p.measureText(text);
            // Kurdish/Arabic text moves left-to-right, English text moves right-to-left
            rtl = text.matches(".*[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFEFF].*");
            needReset = true;
            invalidate();
        }

        void setRunning(boolean r) {
            if (r == running) return;
            running = r;
            last = 0;
            if (r) postInvalidateOnAnimation();
        }

        @Override
        protected void onMeasure(int w, int h) {
            android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            int height = (int) Math.ceil(fm.descent - fm.ascent + pad * 2);
            setMeasuredDimension(MeasureSpec.getSize(w), height);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            needReset = true;
        }

        @Override
        protected void onDraw(android.graphics.Canvas c) {
            if (text.isEmpty() || getWidth() == 0) return;
            if (needReset) {
                x = rtl ? -textW : getWidth();
                needReset = false;
                last = 0;
            }
            long now = android.os.SystemClock.uptimeMillis();
            if (running && last != 0) {
                float dx = speed * (now - last) / 1000f;
                x += rtl ? dx : -dx;
                if (!rtl && x < -textW) x = getWidth();
                if (rtl && x > getWidth()) x = -textW;
            }
            last = now;
            android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            float y = getHeight() / 2f - (fm.ascent + fm.descent) / 2f;
            c.drawText(text, x, y, p);
            if (running) postInvalidateOnAnimation();
        }
    }


    String finalKey(String url) {
        return "fin_" + url.hashCode();
    }

    // Archive.org links first jump (redirect) to the real server. Find that server once
    // and save it, so next time the video opens without the extra jump.
    void resolveArchive(String url) {
        new Thread(() -> {
            try {
                String u = url;
                for (int hop = 0; hop < 6; hop++) {
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setRequestMethod("HEAD");
                    c.setRequestProperty("User-Agent", USER_AGENT);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(15000);
                    int code = c.getResponseCode();
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (code >= 300 && code < 400 && loc != null) {
                        u = new URL(new URL(u), loc).toString();
                        continue;
                    }
                    if (code >= 200 && code < 300 && !u.equals(url)) {
                        prefs.edit().putString(finalKey(url), u).apply();
                    }
                    return;
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    // Videos hosted on Archive.org play like a live channel (continue + loop)
    String durKey(String url) {
        return "dur_" + url.hashCode();
    }

    boolean isLoopChannel(String url) {
        return url != null && url.toLowerCase().contains("archive.org");
    }

    void showStatus(String text) {
        status.setText(text);
        status.setVisibility(View.VISIBLE);
    }

    // ---------- Channel guide ----------

    void openGuide() {
        if (urls.isEmpty()) return;
        guide.setVisibility(View.VISIBLE);
        list.requestFocus();
        int pos = Math.max(current, 0);
        list.setSelection(pos);
        list.setItemChecked(pos, true);
        resetGuideTimer();
    }

    void closeGuide() {
        guide.setVisibility(View.GONE);
        h.removeCallbacks(hideGuide);
        hideSystemUi();
    }

    void resetGuideTimer() {
        h.removeCallbacks(hideGuide);
        if (guide.getVisibility() == View.VISIBLE) h.postDelayed(hideGuide, 12000);
    }

    // ---------- Remote control ----------

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        if (blockedNow && k != KeyEvent.KEYCODE_BACK && k != KeyEvent.KEYCODE_HOME) return true;

        if (act.getVisibility() == View.VISIBLE) {
            if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_0));
                return true;
            }
            if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_NUMPAD_0));
                return true;
            }
            if (k == KeyEvent.KEYCODE_DEL) {
                if (down) press("del");
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        boolean center = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (swallowCenterUp && center && !down) {
            swallowCenterUp = false;
            return true;
        }

        if (guide.getVisibility() == View.VISIBLE) {
            resetGuideTimer();
            if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
                if (down) closeGuide();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        // Volume: Right = louder, Left = quieter (holding the button keeps changing it)
        if (k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_LEFT) {
            if (down) {
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        k == KeyEvent.KEYCODE_DPAD_RIGHT ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI);
            }
            return true;
        }

        // Number buttons: type the channel number, like a satellite receiver
        int digit = -1;
        if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) digit = k - KeyEvent.KEYCODE_0;
        else if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) digit = k - KeyEvent.KEYCODE_NUMPAD_0;
        if (digit >= 0) {
            if (down && e.getRepeatCount() == 0) typeDigit(digit);
            return true;
        }

        boolean next = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP;
        boolean prev = k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN;
        if (next || prev || center) {
            if (down && e.getRepeatCount() == 0) {
                if (next) tune(current < 0 ? 0 : current + 1);
                else if (prev) tune(current < 0 ? 0 : current - 1);
                else {
                    swallowCenterUp = true;
                    openGuide();
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    void typeDigit(int d) {
        if (urls.isEmpty()) return;
        if (numBuf.length() >= 4) numBuf = "";
        numBuf += d;
        osd.setText(numBuf + " _");
        osd.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideOsd);
        h.removeCallbacks(numGo);
        // Enough digits for the highest channel number: open now, otherwise wait 2 seconds
        if (numBuf.length() >= String.valueOf(urls.size()).length()) h.postDelayed(numGo, 300);
        else h.postDelayed(numGo, 2000);
    }

    void goNumber() {
        String b = numBuf;
        numBuf = "";
        if (b.isEmpty()) return;
        int n;
        try { n = Integer.parseInt(b); } catch (Exception ex) { return; }
        if (n >= 1 && n <= urls.size()) {
            tune(n - 1);
        } else {
            osd.setText(b + "   No channel");
            osd.setVisibility(View.VISIBLE);
            h.removeCallbacks(hideOsd);
            h.postDelayed(hideOsd, 2000);
        }
    }

    // ---------- Automatic update from GitHub Releases ----------

    int myVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception ex) {
            return Integer.MAX_VALUE;
        }
    }

    void checkUpdate() {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(RELEASE_API).openConnection();
                c.setRequestProperty("User-Agent", "MohammedTV");
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                }
                JSONObject rel = new JSONObject(sb.toString());
                int latest = Integer.parseInt(rel.optString("tag_name", "v0").replaceAll("[^0-9]", "0").replaceFirst("^0+(?=.)", ""));
                if (latest <= myVersion()) return;
                String apkUrl = null;
                JSONArray assets = rel.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject a = assets.getJSONObject(i);
                        if (a.optString("name").toLowerCase().endsWith(".apk")) {
                            apkUrl = a.optString("browser_download_url");
                            break;
                        }
                    }
                }
                if (apkUrl == null) return;
                final String u = apkUrl;
                runOnUiThread(() -> askUpdate(u));
            } catch (Exception ignored) {
            }
        }).start();
    }

    void askUpdate(String apkUrl) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle("New update available")
                .setMessage("A new version of Mohammed TV is ready. Update now?")
                .setPositiveButton("Update", (d, w) -> downloadUpdate(apkUrl))
                .setNegativeButton("Later", null)
                .show();
    }

    void downloadUpdate(String apkUrl) {
        AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("Updating Mohammed TV")
                .setMessage("Downloading… 0%")
                .setCancelable(false)
                .show();
        new Thread(() -> {
            File dir = getExternalCacheDir() != null ? getExternalCacheDir() : getCacheDir();
            File f = new File(dir, "MohammedTV-update.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "MohammedTV");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                int total = c.getContentLength();
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[16384];
                    long got = 0;
                    int n, lastPct = -1;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        if (total > 0) {
                            int pct = (int) (got * 100 / total);
                            if (pct != lastPct) {
                                lastPct = pct;
                                runOnUiThread(() -> progress.setMessage("Downloading… " + pct + "%"));
                            }
                        }
                    }
                }
                runOnUiThread(() -> {
                    progress.dismiss();
                    installApk(f);
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    progress.dismiss();
                    new AlertDialog.Builder(this)
                            .setMessage("The update couldn't be downloaded. Check your internet and try again later.")
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        }).start();
    }

    boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    void installApk(File f) {
        if (!canInstall()) {
            // Android 8+: the user must allow this app to install updates (only once)
            pendingApk = f;
            new AlertDialog.Builder(this)
                    .setTitle("One-time permission")
                    .setMessage("To install the update, turn on \"Allow from this source\" for Mohammed TV on the next screen, then come back.")
                    .setPositiveButton("OK", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception ex) {
                            try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); } catch (Exception ignored) { }
                        }
                    })
                    .show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            Uri uri;
            if (Build.VERSION.SDK_INT >= 24) {
                uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                uri = Uri.fromFile(f);
            }
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ex) {
            new AlertDialog.Builder(this)
                    .setMessage("The update couldn't be opened on this device.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    // ---------- Protection: no VPN, no proxy, no sniffing apps ----------

    String securityProblem() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= 23) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities c = cm.getNetworkCapabilities(n);
                    if (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        return "Please turn off your VPN to watch Mohammed TV.";
                    }
                }
            }
        } catch (Exception ignored) { }
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                String name = ni.getName();
                if (ni.isUp() && (name.startsWith("tun") || name.startsWith("ppp") || name.startsWith("tap"))) {
                    return "Please turn off your VPN to watch Mohammed TV.";
                }
            }
        } catch (Exception ignored) { }
        String proxy = System.getProperty("http.proxyHost");
        if (proxy != null && !proxy.trim().isEmpty()) {
            return "Please turn off the proxy in your Wi-Fi settings to watch Mohammed TV.";
        }
        PackageManager pm = getPackageManager();
        for (String pkg : SNIFFERS) {
            try {
                pm.getPackageInfo(pkg, 0);
                return "A network capture app is installed on this device.\nUninstall it to watch Mohammed TV.";
            } catch (Exception ignored) { }
        }
        return null;
    }

    void guard() {
        String problem = securityProblem();
        if (problem != null) {
            if (player != null) player.stop();
            blocker.setText(problem);
            blocker.setVisibility(View.VISIBLE);
            blockedNow = true;
        } else if (blockedNow) {
            blockedNow = false;
            blocker.setVisibility(View.GONE);
            if (prefs.getBoolean("activated", false)) {
                if (urls.isEmpty()) start();
                else tune(Math.max(current, 0));
            }
        }
    }

    // ---------- Screen / lifecycle ----------

    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        h.removeCallbacks(guardLoop);
        h.postDelayed(guardLoop, 4000);
        guard();
        if (pendingApk != null && canInstall()) {
            File f = pendingApk;
            pendingApk = null;
            installApk(f);
        }
        if (player != null && current >= 0 && !blockedNow) {
            long d = 0;
            if (current < urls.size() && isLoopChannel(urls.get(current))) {
                d = 0; // live feature off
            }
            if (d > 0) player.seekTo(System.currentTimeMillis() % d);
            else player.seekToDefaultPosition();
            player.prepare();
            player.play();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        h.removeCallbacks(guardLoop);
        if (player != null) player.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        if (mediaCache != null) {
            try { mediaCache.release(); } catch (Throwable ignored) { }
            mediaCache = null;
        }
    }

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
