package com.mohammed.tv;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Collections;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final String PLAYLIST_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.m3u";
    static final String USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20";
    static final String CODE_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/code.txt";
    static final String DAT_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.dat";
    static final String DEFAULT_CODE = "1010";
    boolean checking = false;
    boolean blockedNow = false;
    TextView blocker;

    // Network capture / sniffing apps. If any is installed, the app will not play.
    static final String[] SNIFFERS = {
            "com.guoshi.httpcanary", "com.guoshi.httpcanary.premium",
            "app.greyshirts.sslcapture", "com.emanuelef.remote_capture",
            "com.minhui.networkcapture", "com.minhui.networkcapture.pro",
            "com.reqable.android"
    };
    final Runnable guardLoop = new Runnable() {
        @Override public void run() { guard(); h.postDelayed(this, 4000); }
    };

    SharedPreferences prefs;
    ExoPlayer player;
    PlayerView playerView;
    TextView osd, status, dots, msg;
    View guide, act, tap;
    ListView list;
    ArrayAdapter<String> adapter;

    final List<String> names = new ArrayList<>();
    final List<String> urls = new ArrayList<>();
    final List<String> labels = new ArrayList<>();
    final List<Button> keys = new ArrayList<>();

    int current = -1;
    int retries = 0;
    String code = "";
    boolean swallowCenterUp = false;
    boolean syncPending = false; // Archive.org channels: jump to the 'live' moment once ready

    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable hideOsd = () -> osd.setVisibility(View.GONE);
    final Runnable hideGuide = this::closeGuide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        prefs = getSharedPreferences("mtv", MODE_PRIVATE);
        playerView = findViewById(R.id.player);
        osd = findViewById(R.id.osd);
        status = findViewById(R.id.status);
        guide = findViewById(R.id.guide);
        list = findViewById(R.id.list);
        act = findViewById(R.id.act);
        dots = findViewById(R.id.dots);
        msg = findViewById(R.id.msg);
        tap = findViewById(R.id.tap);
        blocker = findViewById(R.id.blocker);

        // Player that behaves like VLC: any link, http or https, with a VLC user agent
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(USER_AGENT)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(this, http);
        // Start playing after 1 second of video is loaded (default was 2.5 seconds)
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15000, 50000, 1000, 2000)
                .build();
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSource))
                .setLoadControl(loadControl)
                .build();
        playerView.setPlayer(player);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setKeepScreenOn(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    retries = 0;
                    if (syncPending) {
                        syncPending = false;
                        long d = player.getDuration();
                        if (d != C.TIME_UNSET && d > 0) {
                            // Remember the length, so next time the channel opens directly at the right moment
                            if (current >= 0 && current < urls.size()) {
                                prefs.edit().putLong(durKey(urls.get(current)), d).apply();
                            }
                            // Same moment for everyone, based on the clock, like real live TV
                            player.seekTo(System.currentTimeMillis() % d);
                        }
                    }
                    status.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    showStatus("Loading…");
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                showStatus("This channel isn't available right now. Try another one.");
            }
        });

        adapter = new ArrayAdapter<>(this, R.layout.item_channel, labels);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            tune(position);
            closeGuide();
        });
        list.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView v, int s) { resetGuideTimer(); }
            @Override public void onScroll(android.widget.AbsListView v, int a, int b, int c) { }
        });

        tap.setOnClickListener(v -> {
            if (guide.getVisibility() == View.VISIBLE) closeGuide();
            else openGuide();
        });

        buildKeypad();

        guard();
        if (prefs.getBoolean("activated", false)) {
            if (!blockedNow) start();
        } else {
            act.setVisibility(View.VISIBLE);
            drawCode();
            if (!keys.isEmpty()) keys.get(0).requestFocus();
        }
    }

    // ---------- Activation ----------

    void buildKeypad() {
        GridLayout pad = findViewById(R.id.pad);
        String[] labelsArr = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK"};
        int size = dp(76);
        int gap = dp(6);
        for (String k : labelsArr) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setGravity(Gravity.CENTER);
            b.setFocusable(true);
            b.setBackgroundResource(R.drawable.key_bg);
            b.setTextColor(k.equals("OK") ? 0xFFF5B83D : 0xFFEAF1F8);
            b.setStateListAnimator(null);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = (int) (size * 1.25);
            lp.height = size;
            lp.setMargins(gap, gap, gap, gap);
            b.setLayoutParams(lp);
            final String key = k.equals("⌫") ? "del" : k.equals("OK") ? "ok" : k;
            b.setOnClickListener(v -> press(key));
            pad.addView(b);
            keys.add(b);
        }
    }

    void press(String k) {
        msg.setText("");
        if (k.equals("del")) {
            if (code.length() > 0) code = code.substring(0, code.length() - 1);
        } else if (k.equals("ok")) {
            check();
            return;
        } else if (code.length() < 4) {
            code += k;
            if (code.length() == 4) {
                drawCode();
                h.postDelayed(this::check, 250);
                return;
            }
        }
        drawCode();
    }

    void check() {
        if (checking) return;
        checking = true;
        final String entered = code;
        msg.setText("Checking…");
        new Thread(() -> {
            // The activation code lives in code.txt on GitHub, so it can be changed any time
            long t = System.currentTimeMillis();
            String remote = codeFrom(decrypt(download(DAT_URL + "?t=" + t)));
            if (remote == null) {
                remote = download(CODE_URL + "?t=" + t);
                if (remote != null && remote.contains("<")) remote = null;
            }
            if (remote != null) remote = remote.trim();
            final String fetched = (remote != null && !remote.isEmpty() && remote.length() <= 20) ? remote : null;
            h.post(() -> {
                checking = false;
                if (fetched != null) prefs.edit().putString("lastCode", fetched).apply();
                String expected = fetched != null ? fetched : prefs.getString("lastCode", DEFAULT_CODE);
                if (entered.equals(expected)) {
                    prefs.edit().putBoolean("activated", true).apply();
                    msg.setText("");
                    act.setVisibility(View.GONE);
                    start();
                } else {
                    msg.setText(fetched == null ? "No internet. Connect and try again." : "Wrong code. Try again.");
                    code = "";
                    drawCode();
                }
            });
        }).start();
    }

    void drawCode() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(i < code.length() ? "●" : "○");
            if (i < 3) sb.append(' ');
        }
        dots.setText(sb.toString());
    }

    // ---------- Playlist ----------

    void start() {
        if (blockedNow) return;
        String cached = decrypt(prefs.getString("dat", null));
        if (cached == null) cached = prefs.getString("playlist", null);
        if (cached != null) {
            parse(cached);
            if (!urls.isEmpty()) tune(0);
        }
        if (urls.isEmpty()) showStatus("Loading channels…");
        new Thread(() -> {
            long t = System.currentTimeMillis();
            String enc = download(DAT_URL + "?t=" + t);
            String text = decrypt(enc);
            boolean fromDat = text != null;
            if (!fromDat) text = download(PLAYLIST_URL + "?t=" + t);
            final String result = text;
            if (result == null || !result.contains("#EXT")) {
                h.post(() -> { if (urls.isEmpty()) showStatus("Can't load channels. Check the internet."); });
                return;
            }
            h.post(() -> {
                if (fromDat) prefs.edit().putString("dat", enc.trim()).remove("playlist").apply();
                else prefs.edit().putString("playlist", result).apply();
                parse(result);
                if (current < 0 || current >= urls.size()) {
                    if (!urls.isEmpty()) tune(0);
                }
            });
        }).start();
    }

    // Playlist is published encrypted (playlist.dat); only this app can read it
    String decrypt(String b64) {
        if (b64 == null) return null;
        try {
            byte[] raw = android.util.Base64.decode(b64.trim(), android.util.Base64.DEFAULT);
            if (raw.length <= 256) return null;
        String[] p = {
                "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDBAnZiRA9gLSUdXm6qsCJMQdiD",
                "iA/2vvAh+Hp7QXlamaWZYf1vpBofGrrp7OsqIDS8BgvcvZXWT0vD7t/6RFRu8ABE8UGQF5FCByzV",
                "ZPH18D4OhP00SQTnqnumYRyXRGF8x1nLuRa/X4r17cr5i+gxGbafipwq+N8edSPBusflaYgb07Qu",
                "Ew2Ogah42MDT7BmAroeua7LQJaGoGlVKOyNeFhKwZEsZJMAnVFv4tjxdpZzGf+JhBP/edJn1VO4z",
                "flzxmHViSlN3j3XqJYgot3xKUJb7v1Nc1rXEkQ1qWW8azOP0lb1m40m2OVlwrwq+SXe8DpyrUQNW",
                "hDiNtyV1O6mhAgMBAAECggEACvKyP0JR7rQ622jNjVcst9+Bifr2IFp97ahd/rc03HC0E/Bq7znr",
                "TSW/kdixcXAWm656Xmbe3KNedmaKrAQTl8AbfM2kSNmMYNbeOjvFzYv3Qiy1HeHRMlihV0uBgxtS",
                "7hBzAY89+QSg8dCfa4KuDNhy+2dh8r5PjidJ/CGFmJe3oNDkI3nu5Lv1RVu52LLCUgTEKbFFFjJT",
                "T7sdiCww9HZ3ocsXmqQub5ZKV0T21aIYbjUyZIbSkfdOAyVRwHITFLP9/OM+PN1uzbLMqkCxnQfe",
                "l+XwO8mG/6Ke7NEKYyu6nW8tbOOVVP5DZvhqxBvkwJqHREyAZeDk7C8bnOc8MQKBgQD8Fycv1CFw",
                "oRnjhPI2WlUeXrYVXmqRGlLijq+3iRFNb3iabXHBKe0CrcYH0jsqoyc6daKQgJLn5FIhN/sDcqhP",
                "V5neABpgAQE++xpgMKqNXQe3loG5OKvsEUF7LLIyABo1Lsa80TBHqhvuMNZrY9kITjlbPJnPM3gp",
                "Bz6SA2qjsQKBgQDEAL9Njp/mshjn8/K3Qmi0+8mmLLuvGauLc4OAVXToFIoAGKYql6zocwur74pJ",
                "FavGPTZNoWcJ3IpCwNCOauwYutnPDCACQvW5R/vY8o4s9nh9AP9Sew5tFWD2yrUoJXIdhqKiC9ca",
                "imf2qIu5HqmNAsoYdP501tUjOC/gowSQ8QKBgE4qW7M/4nKK8X0TvwrNbbEyCuGLWh3N/L9VIPUW",
                "4i+RjeLMZsZPWrdG7K2GKWRqHILK8PI/e829hR3ZvtJt3fRkJEiq3YLBLQK7V41V6bxViUwKtgSZ",
                "pu1W2Gf6DvLkBzxQWb04W/EMtQZhTEsWNbiWkMBShRqzSeHm5ibeOlWxAoGAMVve0TExo28GRqNw",
                "ZCYdKDagOXDacuYMBTo5y3+5yRgjCJMshV1c9czDC7FvKaiDcZDItBQJVrprNxRHcRYMDs4/O5za",
                "Ere6Gca+7Ytnsnr/LLurkKHcqCvSF1RE+q8zZawaGKTSrqRcOgmH5j6KhDBHpJER42qWkh/8Lp3e",
                "8IECgYBalrIxJ1LP3rrWTmrIO1dMe/nSJv77MGxdIy0Y8evv29+v7/nuBoxV+EaeK7aqpB2VVPD7",
                "ivf+JGN3or3XsQZi7TpgErL5FLIYTzHuoZXVkex+EGrxRkyLMIJbgoLaAC0hRm78jSV6Vd3ZCkUr",
                "k0xcwLudM+1LX47tchJH8dqCvQ=="
        };
            StringBuilder sb = new StringBuilder();
            for (String x : p) sb.append(x);
            PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(
                    new PKCS8EncodedKeySpec(android.util.Base64.decode(sb.toString(), android.util.Base64.DEFAULT)));
            Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsa.init(Cipher.DECRYPT_MODE, pk);
            byte[] kv = rsa.doFinal(Arrays.copyOfRange(raw, 0, 256));
            if (kv.length != 48) return null;
            Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
            aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(Arrays.copyOfRange(kv, 0, 32), "AES"),
                    new IvParameterSpec(Arrays.copyOfRange(kv, 32, 48)));
            return new String(aes.doFinal(Arrays.copyOfRange(raw, 256, raw.length)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    static String codeFrom(String text) {
        if (text == null) return null;
        for (String line : text.split("\n")) {
            line = line.trim();
            if (line.startsWith("#CODE:")) {
                String c = line.substring(6).trim();
                return c.isEmpty() ? null : c;
            }
        }
        return null;
    }

    String download(String address) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    void parse(String text) {
        names.clear();
        urls.clear();
        labels.clear();
        String name = null;
        for (String raw : text.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                int comma = line.lastIndexOf(',');
                name = comma >= 0 ? line.substring(comma + 1).trim() : null;
            } else if (!line.startsWith("#")) {
                String n = (name == null || name.isEmpty()) ? "Channel " + (urls.size() + 1) : name;
                names.add(n);
                urls.add(line);
                labels.add((urls.size()) + "    " + n);
                name = null;
            }
        }
        adapter.notifyDataSetChanged();
        if (current >= 0 && current < urls.size()) list.setItemChecked(current, true);
    }

    // ---------- Playback ----------

    void tune(int i) {
        if (blockedNow) return;
        int n = urls.size();
        if (n == 0) return;
        current = ((i % n) + n) % n;
        retries = 0;
        String url = urls.get(current);
        osd.setText((current + 1) + "   " + names.get(current));
        osd.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideOsd);
        h.postDelayed(hideOsd, 3500);
        list.setItemChecked(current, true);

        MediaItem.Builder b = new MediaItem.Builder().setUri(url);
        String low = url.toLowerCase();
        if (low.contains(".m3u8")) {
            b.setMimeType(MimeTypes.APPLICATION_M3U8);
        }
        boolean loopChannel = isLoopChannel(url);
        long knownDur = loopChannel ? prefs.getLong(durKey(url), 0) : 0;
        syncPending = loopChannel && knownDur <= 0;
        player.setRepeatMode(loopChannel ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
        showStatus("Loading…");
        if (knownDur > 0) {
            // Open directly at the live moment: only one load, no jump afterwards
            player.setMediaItem(b.build(), System.currentTimeMillis() % knownDur);
        } else {
            player.setMediaItem(b.build());
        }
        player.prepare();
        player.play();
    }

    // Videos hosted on Archive.org play like a live channel (continue + loop)
    String durKey(String url) {
        return "dur_" + url.hashCode();
    }

    boolean isLoopChannel(String url) {
        return url != null && url.toLowerCase().contains("archive.org");
    }

    void showStatus(String text) {
        status.setText(text);
        status.setVisibility(View.VISIBLE);
    }

    // ---------- Channel guide ----------

    void openGuide() {
        if (urls.isEmpty()) return;
        guide.setVisibility(View.VISIBLE);
        list.requestFocus();
        int pos = Math.max(current, 0);
        list.setSelection(pos);
        list.setItemChecked(pos, true);
        resetGuideTimer();
    }

    void closeGuide() {
        guide.setVisibility(View.GONE);
        h.removeCallbacks(hideGuide);
        hideSystemUi();
    }

    void resetGuideTimer() {
        h.removeCallbacks(hideGuide);
        if (guide.getVisibility() == View.VISIBLE) h.postDelayed(hideGuide, 12000);
    }

    // ---------- Remote control ----------

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        if (blockedNow && k != KeyEvent.KEYCODE_BACK && k != KeyEvent.KEYCODE_HOME) return true;

        if (act.getVisibility() == View.VISIBLE) {
            if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_0));
                return true;
            }
            if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_NUMPAD_0));
                return true;
            }
            if (k == KeyEvent.KEYCODE_DEL) {
                if (down) press("del");
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        boolean center = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (swallowCenterUp && center && !down) {
            swallowCenterUp = false;
            return true;
        }

        if (guide.getVisibility() == View.VISIBLE) {
            resetGuideTimer();
            if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
                if (down) closeGuide();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        boolean next = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP;
        boolean prev = k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN;
        if (next || prev || center) {
            if (down && e.getRepeatCount() == 0) {
                if (next) tune(current < 0 ? 0 : current + 1);
                else if (prev) tune(current < 0 ? 0 : current - 1);
                else {
                    swallowCenterUp = true;
                    openGuide();
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    // ---------- Protection: no VPN, no proxy, no sniffing apps ----------

    String securityProblem() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= 23) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities c = cm.getNetworkCapabilities(n);
                    if (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        return "Please turn off your VPN to watch Mohammed TV.";
                    }
                }
            }
        } catch (Exception ignored) { }
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                String name = ni.getName();
                if (ni.isUp() && (name.startsWith("tun") || name.startsWith("ppp") || name.startsWith("tap"))) {
                    return "Please turn off your VPN to watch Mohammed TV.";
                }
            }
        } catch (Exception ignored) { }
        String proxy = System.getProperty("http.proxyHost");
        if (proxy != null && !proxy.trim().isEmpty()) {
            return "Please turn off the proxy in your Wi-Fi settings to watch Mohammed TV.";
        }
        PackageManager pm = getPackageManager();
        for (String pkg : SNIFFERS) {
            try {
                pm.getPackageInfo(pkg, 0);
                return "A network capture app is installed on this device.\nUninstall it to watch Mohammed TV.";
            } catch (Exception ignored) { }
        }
        return null;
    }

    void guard() {
        String problem = securityProblem();
        if (problem != null) {
            if (player != null) player.stop();
            blocker.setText(problem);
            blocker.setVisibility(View.VISIBLE);
            blockedNow = true;
        } else if (blockedNow) {
            blockedNow = false;
            blocker.setVisibility(View.GONE);
            if (prefs.getBoolean("activated", false)) {
                if (urls.isEmpty()) start();
                else tune(Math.max(current, 0));
            }
        }
    }

    // ---------- Screen / lifecycle ----------

    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        h.removeCallbacks(guardLoop);
        h.postDelayed(guardLoop, 4000);
        guard();
        if (player != null && current >= 0 && !blockedNow) {
            long d = 0;
            if (current < urls.size() && isLoopChannel(urls.get(current))) {
                d = prefs.getLong(durKey(urls.get(current)), 0);
                if (d <= 0) syncPending = true;
            }
            if (d > 0) player.seekTo(System.currentTimeMillis() % d);
            else player.seekToDefaultPosition();
            player.prepare();
            player.play();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        h.removeCallbacks(guardLoop);
        if (player != null) player.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
