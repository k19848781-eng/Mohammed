package com.mohammed.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.widget.ImageView;
import android.content.Intent;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.Settings;
import androidx.core.content.FileProvider;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.datasource.okhttp.OkHttpDataSource;
import okhttp3.OkHttpClient;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.SeekParameters;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.source.ProgressiveMediaSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.cache.CacheWriter;
import java.util.concurrent.ConcurrentHashMap;
import androidx.media3.datasource.cache.CacheDataSource;
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor;
import androidx.media3.datasource.cache.SimpleCache;
import androidx.media3.database.StandaloneDatabaseProvider;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Collections;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final String PLAYLIST_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.m3u";
    static final String USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20";
    static final String CODE_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/code.txt";
    static final String DAT_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.dat";
    static final String DEFAULT_CODE = "1010";
    boolean checking = false;
    boolean blockedNow = false;
    TextView blocker;

    // Network capture / sniffing apps. If any is installed, the app will not play.
    static final String[] SNIFFERS = {
            "com.guoshi.httpcanary", "com.guoshi.httpcanary.premium",
            "app.greyshirts.sslcapture", "com.emanuelef.remote_capture",
            "com.minhui.networkcapture", "com.minhui.networkcapture.pro",
            "com.reqable.android"
    };
    final Runnable guardLoop = new Runnable() {
        @Override public void run() { guard(); h.postDelayed(this, 5000); }
    };

    SharedPreferences prefs;
    ExoPlayer player;
    PlayerView playerView;
    TextView osd, status, dots, msg;
    View guide, act, tap;
    ListView list;
    ArrayAdapter<String> adapter;

    final List<String> names = new ArrayList<>();
    // Your original playlist (from GitHub). names/urls/headers/labels are the customer's personal list
    final List<String> mNames = new ArrayList<>();
    final List<String> mUrls = new ArrayList<>();
    final List<java.util.Map<String, String>> mHeaders = new ArrayList<>();
    final List<String> mLogos = new ArrayList<>();
    final List<String> logos = new ArrayList<>();
    final List<String> urls = new ArrayList<>();
    final List<String> labels = new ArrayList<>();
    // Extra connection details per channel from the playlist (User-Agent, Referer...), like OTT Player uses
    final List<java.util.Map<String, String>> headers = new ArrayList<>();
    final List<Button> keys = new ArrayList<>();

    int current = -1;
    int retries = 0;
    String code = "";
    boolean swallowCenterUp = false;
    String numBuf = "";
    final Runnable numGo = this::goNumber;
    File pendingApk = null;
    static final String RELEASE_API = "https://api.github.com/repos/k19848781-eng/Mohammed/releases/latest";
    boolean syncPending = false;
    // Moving text (news ticker) at the bottom of your own channels
    static final String TICKER_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/ticker.txt";
    // Your logo in the top-right corner of your own channels (no need to add it in CapCut)
    static final String LOGO_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/logo.png";
    ImageView channelLogo;
    android.widget.LinearLayout logoBox;
    FrameLayout tickerBar;
    TickerView tickerText;
    String tickerMsg = "";
    final Runnable tickerRefresh = new Runnable() {
        @Override public void run() {
            fetchTicker();
            fetchLogo();
            h.postDelayed(this, 10 * 60 * 1000);
        }
    };
    SimpleCache mediaCache;                       // stores parts of Archive.org videos on the device
    ProgressiveMediaSource.Factory archiveFactory; // player source for Archive.org videos
    boolean archiveRetried = false;
    // Smart live mode for your own channels (videos in small pieces, .m3u8)
    CacheDataSource.Factory hlsCacheFactory;
    HlsMediaSource.Factory hlsFactory;
    static class HlsInfo { long[] startMs; long[] durMs; String[] uris; long totalMs; }
    final ConcurrentHashMap<String, HlsInfo> hlsInfo = new ConcurrentHashMap<>();
    final java.util.Set<String> prefetched = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>()); // Archive.org channels: jump to the 'live' moment once ready

    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable hideOsd = () -> osd.setVisibility(View.GONE);
    final Runnable hideGuide = this::closeGuide;

    boolean crashScreen = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Crash reporter: if the app crashed last time, show the reason on screen (for a screenshot)
        final android.content.SharedPreferences crashPrefs = getSharedPreferences("crash", MODE_PRIVATE);
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {
            try {
                java.io.StringWriter sw = new java.io.StringWriter();
                ex.printStackTrace(new java.io.PrintWriter(sw));
                crashPrefs.edit().putString("trace", sw.toString()).commit();
            } catch (Throwable ignored) { }
            if (previous != null) previous.uncaughtException(th, ex);
        });
        String lastCrash = crashPrefs.getString("trace", null);
        if (lastCrash != null) {
            crashPrefs.edit().remove("trace").commit();
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            TextView tv = new TextView(this);
            tv.setTextColor(Color.WHITE);
            tv.setBackgroundColor(Color.BLACK);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            tv.setPadding(24, 24, 24, 24);
            tv.setText("Mohammed TV crashed. Please send a screenshot of this to Claude.\n"
                    + "(Open the app again to continue.)\n\n" + lastCrash);
            sv.addView(tv);
            setContentView(sv);
            crashScreen = true;
            return;
        }
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        prefs = getSharedPreferences("mtv", MODE_PRIVATE);
        playerView = findViewById(R.id.player);
        // Phones only: fill the whole screen (TVs stay exactly as before)
        if (!isTvDevice()) {
            playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM);
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                getWindow().setAttributes(lp);
            }
        }
        setupTicker();
        osd = findViewById(R.id.osd);
        status = findViewById(R.id.status);
        guide = findViewById(R.id.guide);
        list = findViewById(R.id.list);
        act = findViewById(R.id.act);
        dots = findViewById(R.id.dots);
        msg = findViewById(R.id.msg);
        tap = findViewById(R.id.tap);
        blocker = findViewById(R.id.blocker);

        // Player that behaves like VLC: any link, http or https, with a VLC user agent
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(USER_AGENT)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(this, http);
        // Start playing after 1 second of video is loaded (default was 2.5 seconds)
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(30000, 60000, 1500, 5000)
                .build();
        // Archive.org videos play directly (no device cache), like the version you tested as fast
        mediaCache = null;
        // Your own channels stream directly (no saving to the TV box's storage, which can be slow)
        hlsCacheFactory = null;
        hlsFactory = new HlsMediaSource.Factory(dataSource);
        // Archive.org videos use OkHttp, a faster connection method (like Chrome): it keeps the
        // connection to Archive.org open and reuses it, instead of reconnecting for every part
        try {
            OkHttpClient ok = new OkHttpClient.Builder()
                    .followRedirects(true)
                    .followSslRedirects(true)
                    .retryOnConnectionFailure(true)
                    .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                    .readTimeout(20, java.util.concurrent.TimeUnit.SECONDS)
                    .build();
            OkHttpDataSource.Factory okFactory = new OkHttpDataSource.Factory(ok)
                    .setUserAgent("Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36");
            archiveFactory = new ProgressiveMediaSource.Factory(okFactory);
        } catch (Throwable t) {
            archiveFactory = null;
        }
        // Forget any saved direct server links from the previous version
        SharedPreferences.Editor ed = prefs.edit();
        for (String k : prefs.getAll().keySet()) if (k.startsWith("fin_")) ed.remove(k);
        ed.apply();
        // Sound: decode every audio type inside the app (AC-3/Dolby, E-AC-3, MP2, DTS...),
        // so it plays on every TV box, even ones without those decoders
        // Only the sound part of the decoder is used (its picture part crashed the app)
        DefaultRenderersFactory renderers = new SoundDecoderRenderersFactory(this);
        // Picture quality: start with a high quality guess (about 6 Mbps); the player only
        // goes lower if the internet can't keep up
        androidx.media3.exoplayer.upstream.DefaultBandwidthMeter bandwidth =
                new androidx.media3.exoplayer.upstream.DefaultBandwidthMeter.Builder(this)
                        .setInitialBitrateEstimate(6_000_000L)
                        .build();
        player = new ExoPlayer.Builder(this, renderers)
                .setBandwidthMeter(bandwidth)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSource))
                .setLoadControl(loadControl)
                .build();
        // Jumps land on the nearest start-point of the picture, so no extra decoding is needed
        player.setSeekParameters(SeekParameters.PREVIOUS_SYNC);
        playerView.setPlayer(player);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setKeepScreenOn(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                h.removeCallbacks(stallCheck);
                if (state == Player.STATE_READY) {
                    retries = 0;
                    webRetried = false;
                    playedOk = true;
                    midTries = 0;
                    updateTicker();
                    if (syncPending) {
                        syncPending = false;
                        long d = player.getDuration();
                        if (d != C.TIME_UNSET && d > 0) {
                            // Remember the length, so next time the channel opens directly at the right moment
                            if (current >= 0 && current < urls.size()) {
                                prefs.edit().putLong(durKey(urls.get(current)), d).apply();
                            }
                            // Same moment for everyone, based on the clock, like real live TV
                            // First time on this device: keep playing from the beginning (no second load).
                            // From the next time, the channel opens directly at the live moment.
                        }
                    }
                    status.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    showStatus("Loading…");
                    // Only for a channel that was already playing: if it freezes for 8 seconds,
                    // quietly do what you did by hand (switch away and back)
                    if (playedOk) h.postDelayed(stallCheck, 8000);
                } else if (state == Player.STATE_ENDED && current >= 0 && current < urls.size()
                        && !isLoopChannel(urls.get(current))) {
                    // A live channel "ended" (the server stopped the stream): reconnect by itself
                    reconnect();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (current >= 0 && current < urls.size()) {
                    String u = urls.get(current);
                    if (isLoopChannel(u) && !archiveRetried && prefs.contains(finalKey(u))) {
                        // The saved direct server link stopped working: forget it and try the normal link
                        archiveRetried = true;
                        prefs.edit().remove(finalKey(u)).apply();
                        tune(current);
                        return;
                    }
                }
                // Error in the middle of a channel that was playing: reopen it quietly.
                // A channel that never started shows "not available" right away.
                // Web page channel: its video link may have expired, so look it up again (once)
                if (current >= 0 && current < urls.size() && urls.get(current).contains("#web") && !webRetried) {
                    webRetried = true;
                    webFound.remove(urls.get(current).replace("#web", "").replace("#noticker", "").trim());
                    silentTune = true;
                    tune(current);
                    silentTune = false;
                    return;
                }
                if (midReconnect()) return;
                showStatus("This channel isn't available right now. Try another one.");
            }
        });

        adapter = new ArrayAdapter<>(this, R.layout.item_channel, labels);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            tune(position);
            closeGuide();
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            channelMenu(position);
            return true;
        });
        list.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView v, int s) { resetGuideTimer(); }
            @Override public void onScroll(android.widget.AbsListView v, int a, int b, int c) { }
        });

        tap.setOnClickListener(v -> {
            if (guide.getVisibility() == View.VISIBLE) closeGuide();
            else openGuide();
        });

        buildKeypad();

        guard();
        if (prefs.getBoolean("activated", false)) {
            if (!blockedNow) start();
        } else {
            act.setVisibility(View.VISIBLE);
            drawCode();
            if (!keys.isEmpty()) keys.get(0).requestFocus();
        }
        h.postDelayed(this::checkUpdate, 6000);
        h.postDelayed(tickerRefresh, 2000);
    }

    // ---------- Activation ----------

    void buildKeypad() {
        GridLayout pad = findViewById(R.id.pad);
        String[] labelsArr = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK"};
        int size = dp(76);
        int gap = dp(6);
        for (String k : labelsArr) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setGravity(Gravity.CENTER);
            b.setFocusable(true);
            b.setBackgroundResource(R.drawable.key_bg);
            b.setTextColor(k.equals("OK") ? 0xFFF5B83D : 0xFFEAF1F8);
            b.setStateListAnimator(null);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = (int) (size * 1.25);
            lp.height = size;
            lp.setMargins(gap, gap, gap, gap);
            b.setLayoutParams(lp);
            final String key = k.equals("⌫") ? "del" : k.equals("OK") ? "ok" : k;
            b.setOnClickListener(v -> press(key));
            pad.addView(b);
            keys.add(b);
        }
    }

    void press(String k) {
        msg.setText("");
        if (k.equals("del")) {
            if (code.length() > 0) code = code.substring(0, code.length() - 1);
        } else if (k.equals("ok")) {
            check();
            return;
        } else if (code.length() < 4) {
            code += k;
            if (code.length() == 4) {
                drawCode();
                h.postDelayed(this::check, 250);
                return;
            }
        }
        drawCode();
    }

    void check() {
        if (checking) return;
        checking = true;
        final String entered = code;
        msg.setText("Checking…");
        new Thread(() -> {
            // The activation code lives in code.txt on GitHub, so it can be changed any time
            long t = System.currentTimeMillis();
            String remote = codeFrom(decrypt(download(DAT_URL + "?t=" + t)));
            if (remote == null) {
                remote = download(CODE_URL + "?t=" + t);
                if (remote != null && remote.contains("<")) remote = null;
            }
            if (remote != null) remote = remote.trim();
            final String fetched = (remote != null && !remote.isEmpty() && remote.length() <= 20) ? remote : null;
            h.post(() -> {
                checking = false;
                if (fetched != null) prefs.edit().putString("lastCode", fetched).apply();
                String expected = fetched != null ? fetched : prefs.getString("lastCode", DEFAULT_CODE);
                if (entered.equals(expected)) {
                    prefs.edit().putBoolean("activated", true).apply();
                    msg.setText("");
                    act.setVisibility(View.GONE);
                    start();
                } else {
                    msg.setText(fetched == null ? "No internet. Connect and try again." : "Wrong code. Try again.");
                    code = "";
                    drawCode();
                }
            });
        }).start();
    }

    void drawCode() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(i < code.length() ? "●" : "○");
            if (i < 3) sb.append(' ');
        }
        dots.setText(sb.toString());
    }

    // ---------- Playlist ----------

    void start() {
        if (blockedNow) return;
        String cached = decrypt(prefs.getString("dat", null));
        if (cached == null) cached = prefs.getString("playlist", null);
        if (cached != null) {
            parse(cached);
            if (!urls.isEmpty()) tune(0);
        }
        if (urls.isEmpty()) showStatus("Loading channels…");
        new Thread(() -> {
            long t = System.currentTimeMillis();
            String enc = download(DAT_URL + "?t=" + t);
            String text = decrypt(enc);
            boolean fromDat = text != null;
            if (!fromDat) text = download(PLAYLIST_URL + "?t=" + t);
            final String result = text;
            if (result == null || !result.contains("#EXT")) {
                h.post(() -> { if (urls.isEmpty()) showStatus("Can't load channels. Check the internet."); });
                return;
            }
            h.post(() -> {
                if (fromDat) prefs.edit().putString("dat", enc.trim()).remove("playlist").apply();
                else prefs.edit().putString("playlist", result).apply();
                parse(result);
                if (current < 0 || current >= urls.size()) {
                    if (!urls.isEmpty()) tune(0);
                }
            });
        }).start();
    }

    // Playlist is published encrypted (playlist.dat); only this app can read it
    String decrypt(String b64) {
        if (b64 == null) return null;
        try {
            byte[] raw = android.util.Base64.decode(b64.trim(), android.util.Base64.DEFAULT);
            if (raw.length <= 256) return null;
        String[] p = {
                "MIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDBAnZiRA9gLSUdXm6qsCJMQdiD",
                "iA/2vvAh+Hp7QXlamaWZYf1vpBofGrrp7OsqIDS8BgvcvZXWT0vD7t/6RFRu8ABE8UGQF5FCByzV",
                "ZPH18D4OhP00SQTnqnumYRyXRGF8x1nLuRa/X4r17cr5i+gxGbafipwq+N8edSPBusflaYgb07Qu",
                "Ew2Ogah42MDT7BmAroeua7LQJaGoGlVKOyNeFhKwZEsZJMAnVFv4tjxdpZzGf+JhBP/edJn1VO4z",
                "flzxmHViSlN3j3XqJYgot3xKUJb7v1Nc1rXEkQ1qWW8azOP0lb1m40m2OVlwrwq+SXe8DpyrUQNW",
                "hDiNtyV1O6mhAgMBAAECggEACvKyP0JR7rQ622jNjVcst9+Bifr2IFp97ahd/rc03HC0E/Bq7znr",
                "TSW/kdixcXAWm656Xmbe3KNedmaKrAQTl8AbfM2kSNmMYNbeOjvFzYv3Qiy1HeHRMlihV0uBgxtS",
                "7hBzAY89+QSg8dCfa4KuDNhy+2dh8r5PjidJ/CGFmJe3oNDkI3nu5Lv1RVu52LLCUgTEKbFFFjJT",
                "T7sdiCww9HZ3ocsXmqQub5ZKV0T21aIYbjUyZIbSkfdOAyVRwHITFLP9/OM+PN1uzbLMqkCxnQfe",
                "l+XwO8mG/6Ke7NEKYyu6nW8tbOOVVP5DZvhqxBvkwJqHREyAZeDk7C8bnOc8MQKBgQD8Fycv1CFw",
                "oRnjhPI2WlUeXrYVXmqRGlLijq+3iRFNb3iabXHBKe0CrcYH0jsqoyc6daKQgJLn5FIhN/sDcqhP",
                "V5neABpgAQE++xpgMKqNXQe3loG5OKvsEUF7LLIyABo1Lsa80TBHqhvuMNZrY9kITjlbPJnPM3gp",
                "Bz6SA2qjsQKBgQDEAL9Njp/mshjn8/K3Qmi0+8mmLLuvGauLc4OAVXToFIoAGKYql6zocwur74pJ",
                "FavGPTZNoWcJ3IpCwNCOauwYutnPDCACQvW5R/vY8o4s9nh9AP9Sew5tFWD2yrUoJXIdhqKiC9ca",
                "imf2qIu5HqmNAsoYdP501tUjOC/gowSQ8QKBgE4qW7M/4nKK8X0TvwrNbbEyCuGLWh3N/L9VIPUW",
                "4i+RjeLMZsZPWrdG7K2GKWRqHILK8PI/e829hR3ZvtJt3fRkJEiq3YLBLQK7V41V6bxViUwKtgSZ",
                "pu1W2Gf6DvLkBzxQWb04W/EMtQZhTEsWNbiWkMBShRqzSeHm5ibeOlWxAoGAMVve0TExo28GRqNw",
                "ZCYdKDagOXDacuYMBTo5y3+5yRgjCJMshV1c9czDC7FvKaiDcZDItBQJVrprNxRHcRYMDs4/O5za",
                "Ere6Gca+7Ytnsnr/LLurkKHcqCvSF1RE+q8zZawaGKTSrqRcOgmH5j6KhDBHpJER42qWkh/8Lp3e",
                "8IECgYBalrIxJ1LP3rrWTmrIO1dMe/nSJv77MGxdIy0Y8evv29+v7/nuBoxV+EaeK7aqpB2VVPD7",
                "ivf+JGN3or3XsQZi7TpgErL5FLIYTzHuoZXVkex+EGrxRkyLMIJbgoLaAC0hRm78jSV6Vd3ZCkUr",
                "k0xcwLudM+1LX47tchJH8dqCvQ=="
        };
            StringBuilder sb = new StringBuilder();
            for (String x : p) sb.append(x);
            PrivateKey pk = KeyFactory.getInstance("RSA").generatePrivate(
                    new PKCS8EncodedKeySpec(android.util.Base64.decode(sb.toString(), android.util.Base64.DEFAULT)));
            Cipher rsa = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            rsa.init(Cipher.DECRYPT_MODE, pk);
            byte[] kv = rsa.doFinal(Arrays.copyOfRange(raw, 0, 256));
            if (kv.length != 48) return null;
            Cipher aes = Cipher.getInstance("AES/CBC/PKCS5Padding");
            aes.init(Cipher.DECRYPT_MODE, new SecretKeySpec(Arrays.copyOfRange(kv, 0, 32), "AES"),
                    new IvParameterSpec(Arrays.copyOfRange(kv, 32, 48)));
            return new String(aes.doFinal(Arrays.copyOfRange(raw, 256, raw.length)), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return null;
        }
    }

    static String codeFrom(String text) {
        if (text == null) return null;
        for (String line : text.split("\n")) {
            line = line.trim();
            if (line.startsWith("#CODE:")) {
                String c = line.substring(6).trim();
                return c.isEmpty() ? null : c;
            }
        }
        return null;
    }

    String download(String address) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // Reads key="value" from an #EXTINF line
    static String attr(String line, String key) {
        String low = line.toLowerCase();
        int i = low.indexOf(key.toLowerCase() + "=\"");
        if (i < 0) return null;
        int start = i + key.length() + 2;
        int end = line.indexOf('"', start);
        if (end < 0) return null;
        String v = line.substring(start, end).trim();
        return v.isEmpty() ? null : v;
    }

    void parse(String text) {
        String keepUrl = (current >= 0 && current < urls.size()) ? urls.get(current) : null;
        mNames.clear();
        mUrls.clear();
        mHeaders.clear();
        mLogos.clear();
        String name = null;
        String logo = null;
        java.util.Map<String, String> hdr = new java.util.HashMap<>();
        for (String raw : text.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                int comma = line.lastIndexOf(',');
                name = comma >= 0 ? line.substring(comma + 1).trim() : null;
                logo = attr(line, "tvg-logo");
                String ua = attr(line, "user-agent");
                if (ua == null) ua = attr(line, "http-user-agent");
                if (ua != null) hdr.put("User-Agent", ua);
                String ref = attr(line, "http-referrer");
                if (ref == null) ref = attr(line, "referer");
                if (ref != null) hdr.put("Referer", ref);
            } else if (line.startsWith("#EXTVLCOPT:")) {
                String opt = line.substring(11).trim();
                int eq = opt.indexOf('=');
                if (eq > 0) {
                    String k = opt.substring(0, eq).trim().toLowerCase();
                    String v = opt.substring(eq + 1).trim();
                    if (k.equals("http-user-agent")) hdr.put("User-Agent", v);
                    else if (k.equals("http-referrer") || k.equals("http-referer")) hdr.put("Referer", v);
                    else if (k.equals("http-origin")) hdr.put("Origin", v);
                }
            } else if (line.startsWith("#EXTHTTP:")) {
                try {
                    JSONObject o = new JSONObject(line.substring(9).trim());
                    java.util.Iterator<String> it = o.keys();
                    while (it.hasNext()) { String k = it.next(); hdr.put(k, o.optString(k)); }
                } catch (Exception ignored) { }
            } else if (!line.startsWith("#")) {
                String u = line;
                int bar = u.indexOf('|');
                if (bar > 0) {   // Kodi style: link|User-Agent=...&Referer=...
                    for (String part : u.substring(bar + 1).split("&")) {
                        int eq = part.indexOf('=');
                        if (eq > 0) {
                            String k = part.substring(0, eq).trim();
                            String v = part.substring(eq + 1).trim();
                            try { v = java.net.URLDecoder.decode(v, "UTF-8"); } catch (Exception ignored) { }
                            hdr.put(k, v);
                        }
                    }
                    u = u.substring(0, bar).trim();
                }
                String n = (name == null || name.isEmpty()) ? "Channel " + (urls.size() + 1) : name;
                mNames.add(n);
                mUrls.add(u);
                mHeaders.add(hdr);
                mLogos.add(logo);
                name = null;
                logo = null;
                hdr = new java.util.HashMap<>();
            }
        }
        applyCustom(keepUrl);
        for (String u : urls) if (isOwnHls(u)) loadHlsInfo(cleanUrl(u));
    }

    // ---------- Channel logos (square, small, saved on the device) ----------

    android.util.LruCache<String, android.graphics.Bitmap> logoCache =
            new android.util.LruCache<String, android.graphics.Bitmap>(
                    (int) Math.min(Runtime.getRuntime().maxMemory() / 16, 8L * 1024 * 1024)) {
                @Override protected int sizeOf(String k, android.graphics.Bitmap b) { return b.getByteCount(); }
            };
    final java.util.concurrent.ExecutorService logoPool = java.util.concurrent.Executors.newFixedThreadPool(3);
    final java.util.Set<String> logoLoading = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>());
    final java.util.Set<String> logoFailed = java.util.Collections.newSetFromMap(new ConcurrentHashMap<>());
    android.graphics.Bitmap logoPlaceholder;
    static final int LOGO_PX = 96;

    int logoSizeDp() { return 44; }

    // Square tile with slightly rounded corners; the logo fits inside without being cut
    android.graphics.Bitmap squareTile(android.graphics.Bitmap src) {
        android.graphics.Bitmap out = android.graphics.Bitmap.createBitmap(LOGO_PX, LOGO_PX, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Canvas c = new android.graphics.Canvas(out);
        android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.parseColor("#1C2B42"));
        c.drawRoundRect(new android.graphics.RectF(0, 0, LOGO_PX, LOGO_PX), 12, 12, p);
        if (src != null) {
            float pad = 6;
            float box = LOGO_PX - pad * 2;
            float sc = Math.min(box / src.getWidth(), box / src.getHeight());
            float w = src.getWidth() * sc, hh = src.getHeight() * sc;
            float l = (LOGO_PX - w) / 2f, t = (LOGO_PX - hh) / 2f;
            p.setFilterBitmap(true);
            c.drawBitmap(src, null, new android.graphics.RectF(l, t, l + w, t + hh), p);
        } else {
            // default: small TV drawing for channels without a logo
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(5);
            p.setColor(Color.parseColor("#8FA3BC"));
            c.drawRoundRect(new android.graphics.RectF(22, 34, 74, 70), 6, 6, p);
            c.drawLine(38, 22, 48, 33, p);
            c.drawLine(58, 22, 48, 33, p);
        }
        return out;
    }

    void bindLogo(TextView tv, String url) {
        if (logoPlaceholder == null) logoPlaceholder = squareTile(null);
        tv.setTag(url);
        android.graphics.Bitmap b = (url == null) ? null : logoCache.get(url);
        setRowIcon(tv, b != null ? b : logoPlaceholder);
        if (url != null && b == null && !logoFailed.contains(url)) loadLogo(url);
    }

    void setRowIcon(TextView tv, android.graphics.Bitmap b) {
        android.graphics.drawable.BitmapDrawable d = new android.graphics.drawable.BitmapDrawable(getResources(), b);
        int sz = (int) dp(logoSizeDp());
        d.setBounds(0, 0, sz, sz);
        tv.setCompoundDrawablesRelative(d, null, null, null);
        tv.setCompoundDrawablePadding((int) dp(14));
    }

    void loadLogo(String url) {
        if (!logoLoading.add(url)) return;
        logoPool.execute(() -> {
            android.graphics.Bitmap tile = null;
            File f = new File(new File(getCacheDir(), "logos"), Integer.toHexString(url.hashCode()) + ".png");
            try {
                if (f.exists()) tile = BitmapFactory.decodeFile(f.getPath());
                if (tile == null) {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10)");
                    c.setConnectTimeout(10000);
                    c.setReadTimeout(15000);
                    byte[] data;
                    try (InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream()) {
                        byte[] buf = new byte[8192];
                        int n;
                        while ((n = in.read(buf)) > 0 && bo.size() < 2 * 1024 * 1024) bo.write(buf, 0, n);
                        data = bo.toByteArray();
                    }
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    int sample = 1;
                    while (o.outWidth / (sample * 2) >= LOGO_PX && o.outHeight / (sample * 2) >= LOGO_PX) sample *= 2;
                    o = new BitmapFactory.Options();
                    o.inSampleSize = sample;
                    android.graphics.Bitmap src = BitmapFactory.decodeByteArray(data, 0, data.length, o);
                    if (src != null) {
                        tile = squareTile(src);
                        src.recycle();
                        f.getParentFile().mkdirs();
                        try (FileOutputStream out = new FileOutputStream(f)) {
                            tile.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, out);
                        }
                    }
                }
            } catch (Throwable ignored) { }
            final android.graphics.Bitmap done = tile;
            logoLoading.remove(url);
            if (done == null) { logoFailed.add(url); return; }
            logoCache.put(url, done);
            runOnUiThread(() -> {
                for (int i = 0; i < list.getChildCount(); i++) {
                    View v = list.getChildAt(i);
                    if (v instanceof TextView && url.equals(v.getTag())) setRowIcon((TextView) v, done);
                }
            });
        });
    }

    // ---------- Personal channel list (search, move, rename, hide) ----------

    java.util.List<String> loadList(String key) {
        java.util.List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (Exception ignored) { }
        return out;
    }

    void saveList(String key, java.util.List<String> l) {
        prefs.edit().putString(key, new JSONArray(l).toString()).apply();
    }

    JSONObject loadNames() {
        try { return new JSONObject(prefs.getString("my_names", "{}")); } catch (Exception e) { return new JSONObject(); }
    }

    // Builds the customer's list from your playlist + their changes. Channel 1 always stays first.
    // New channels you add later appear at the end of their list.
    void applyCustom(String keepUrl) {
        java.util.List<String> order = loadList("my_order");
        java.util.Set<String> hidden = new java.util.HashSet<>(loadList("my_hidden"));
        JSONObject renamed = loadNames();
        java.util.List<Integer> idx = new ArrayList<>();
        if (!mUrls.isEmpty()) idx.add(0);
        java.util.Set<Integer> used = new java.util.HashSet<>(idx);
        for (String key : order) {
            int i = mUrls.indexOf(key);
            if (i > 0 && !used.contains(i) && !hidden.contains(key)) { idx.add(i); used.add(i); }
        }
        for (int i = 1; i < mUrls.size(); i++) {
            if (!used.contains(i) && !hidden.contains(mUrls.get(i))) { idx.add(i); used.add(i); }
        }
        names.clear(); urls.clear(); headers.clear(); labels.clear(); logos.clear();
        for (int i : idx) {
            String u = mUrls.get(i);
            String n = (i > 0) ? renamed.optString(u, mNames.get(i)) : mNames.get(i);
            names.add(n);
            urls.add(u);
            headers.add(mHeaders.get(i));
            logos.add(i < mLogos.size() ? mLogos.get(i) : null);
            labels.add(urls.size() + "    " + n);
        }
        if (keepUrl != null) {
            int k = urls.indexOf(keepUrl);
            if (k >= 0) current = k;
        }
        if (current >= urls.size()) current = urls.isEmpty() ? -1 : 0;
        adapter.notifyDataSetChanged();
        if (current >= 0 && current < urls.size()) list.setItemChecked(current, true);
    }

    String keepCurrentUrl() {
        return (current >= 0 && current < urls.size()) ? urls.get(current) : null;
    }

    android.widget.EditText inputBox(String text, boolean numbers) {
        android.widget.EditText e = new android.widget.EditText(this);
        e.setSingleLine(true);
        if (text != null) { e.setText(text); e.setSelection(text.length()); }
        if (numbers) e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        int p = (int) dp(20);
        e.setPadding(p, p / 2, p, p / 2);
        return e;
    }

    void showKeyboard(AlertDialog d) {
        try {
            d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        } catch (Exception ignored) { }
    }

    // Hold OK (or Menu) on a channel in the list
    void channelMenu(int pos) {
        if (pos < 0 || pos >= urls.size()) return;
        h.removeCallbacks(hideGuide);
        java.util.List<String> items = new ArrayList<>();
        if (pos > 0) {   // channel 1 (shop ad) is locked
            items.add("Rename this channel");
            items.add("Move this channel");
            items.add("Delete this channel");
        }
        items.add("Reset the channel list");
        new AlertDialog.Builder(this)
                .setTitle((pos + 1) + "   " + names.get(pos) + (pos == 0 ? "   (can't be changed)" : ""))
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    String it = items.get(w);
                    if (it.startsWith("Rename")) renameDialog(pos);
                    else if (it.startsWith("Move")) moveDialog(pos);
                    else if (it.startsWith("Delete")) hideChannel(pos);
                    else if (it.startsWith("Reset")) resetDialog();
                })
                .setOnDismissListener(d -> resetGuideTimer())
                .show();
    }

    void searchDialog() {
        android.widget.EditText e = inputBox("", false);
        e.setHint("Channel name");
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Search channels")
                .setView(e)
                .setPositiveButton("Search", (x, w) -> showResults(e.getText().toString()))
                .setNegativeButton("Cancel", null)
                .create();
        e.setOnEditorActionListener((v, a, ev) -> { d.dismiss(); showResults(e.getText().toString()); return true; });
        showKeyboard(d);
        d.show();
        e.requestFocus();
    }

    void showResults(String q) {
        String query = q.trim().toLowerCase();
        if (query.isEmpty()) return;
        java.util.List<Integer> found = new ArrayList<>();
        java.util.List<String> shown = new ArrayList<>();
        for (int i = 0; i < names.size(); i++) {
            if (names.get(i).toLowerCase().contains(query) || String.valueOf(i + 1).equals(query)) {
                found.add(i);
                shown.add((i + 1) + "    " + names.get(i));
            }
        }
        if (found.isEmpty()) {
            new AlertDialog.Builder(this).setMessage("No channel found for \"" + q.trim() + "\".")
                    .setPositiveButton("OK", null).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle(found.size() + " found")
                .setItems(shown.toArray(new String[0]), (d, w) -> {
                    closeGuide();
                    tune(found.get(w));
                })
                .setNegativeButton("Close", null)
                .show();
    }

    void moveDialog(int pos) {
        int max = urls.size();
        android.widget.EditText e = inputBox("", true);
        e.setHint("2 – " + max);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Move \"" + names.get(pos) + "\" to number:")
                .setView(e)
                .setPositiveButton("Move", (x, w) -> {
                    int to;
                    try { to = Integer.parseInt(e.getText().toString().trim()); } catch (Exception ex) { return; }
                    to = Math.max(2, Math.min(max, to));
                    String keep = keepCurrentUrl();
                    java.util.List<String> order = new ArrayList<>(urls.subList(1, urls.size()));
                    String key = urls.get(pos);
                    order.remove(key);
                    order.add(to - 2, key);
                    saveList("my_order", order);
                    applyCustom(keep);
                    list.setSelection(to - 1);
                })
                .setNegativeButton("Cancel", null)
                .create();
        showKeyboard(d);
        d.show();
        e.requestFocus();
    }

    void renameDialog(int pos) {
        String key = urls.get(pos);
        android.widget.EditText e = inputBox(names.get(pos), false);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("Rename channel")
                .setView(e)
                .setPositiveButton("Save", (x, w) -> {
                    JSONObject r = loadNames();
                    String n = e.getText().toString().trim();
                    int mi = mUrls.indexOf(key);
                    try {
                        if (n.isEmpty() || (mi >= 0 && n.equals(mNames.get(mi)))) r.remove(key);
                        else r.put(key, n);
                    } catch (Exception ignored) { }
                    prefs.edit().putString("my_names", r.toString()).apply();
                    applyCustom(keepCurrentUrl());
                    list.setSelection(pos);
                })
                .setNegativeButton("Cancel", null)
                .create();
        showKeyboard(d);
        d.show();
        e.requestFocus();
    }

    void hideChannel(int pos) {
        String key = urls.get(pos);
        new AlertDialog.Builder(this)
                .setTitle("Delete \"" + names.get(pos) + "\"?")
                .setMessage("You can get it back anytime with \"Reset the channel list\".")
                .setPositiveButton("Delete", (x, w) -> {
                    java.util.List<String> hid = loadList("my_hidden");
                    if (!hid.contains(key)) hid.add(key);
                    saveList("my_hidden", hid);
                    boolean wasCurrent = (pos == current);
                    String keep = wasCurrent ? null : keepCurrentUrl();
                    applyCustom(keep);
                    if (wasCurrent && !urls.isEmpty()) tune(Math.min(pos, urls.size() - 1));
                    list.setSelection(Math.min(pos, Math.max(0, urls.size() - 1)));
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    void hiddenDialog() {
        java.util.List<String> hid = loadList("my_hidden");
        java.util.List<String> keys = new ArrayList<>();
        java.util.List<String> shown = new ArrayList<>();
        for (String k : hid) {
            int i = mUrls.indexOf(k);
            if (i >= 0) { keys.add(k); shown.add(mNames.get(i)); }
        }
        if (keys.isEmpty()) {
            new AlertDialog.Builder(this).setMessage("You have no hidden channels.").setPositiveButton("OK", null).show();
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Tap a channel to show it again")
                .setItems(shown.toArray(new String[0]), (d, w) -> {
                    java.util.List<String> h2 = loadList("my_hidden");
                    h2.remove(keys.get(w));
                    saveList("my_hidden", h2);
                    applyCustom(keepCurrentUrl());
                })
                .setNegativeButton("Close", null)
                .show();
    }

    void resetDialog() {
        new AlertDialog.Builder(this)
                .setTitle("Reset the channel list?")
                .setMessage("All renamed, moved and deleted channels go back to the original list.")
                .setPositiveButton("Reset", (x, w) -> {
                    prefs.edit().remove("my_order").remove("my_names").remove("my_hidden").apply();
                    applyCustom(keepCurrentUrl());
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Playback ----------

    void tune(int i) {
        if (blockedNow) return;
        stopGrabber();
        int n = urls.size();
        if (n == 0) return;
        current = ((i % n) + n) % n;
        retries = 0;
        if (!silentTune) { playedOk = false; midTries = 0; }
        String url = urls.get(current);
        if (!isLoopChannel(url) || !prefs.contains(finalKey(url))) archiveRetried = false;
        if (!silentTune) {
            osd.setText((current + 1) + "   " + names.get(current));
            osd.setVisibility(View.VISIBLE);
            h.removeCallbacks(hideOsd);
            h.postDelayed(hideOsd, 3500);
        }
        list.setItemChecked(current, true);

        // Web page channel (link ends with #web): find the video inside the page, then play it
        if (url.contains("#web")) {
            String page = url.replace("#web", "").replace("#noticker", "").trim();
            player.setRepeatMode(Player.REPEAT_MODE_OFF);
            if (!silentTune) showStatus("Loading…");
            updateTicker();
            String[] f = webFound.get(page);
            if (f != null && System.currentTimeMillis() - Long.parseLong(f[1]) < 5 * 60 * 1000L) playWeb(page, f[0]);
            else grabWeb(page, current);
            return;
        }

        String playUrl = url.replace("#noticker", "");
        MediaItem.Builder b = new MediaItem.Builder().setUri(playUrl);
        String low = url.toLowerCase();
        if (low.contains(".m3u8")) {
            b.setMimeType(MimeTypes.APPLICATION_M3U8);
        }
        boolean loopChannel = isLoopChannel(url);
        // Live feature OFF: your own channels always start from the beginning and repeat at the end
        long knownDur = 0;
        syncPending = false;
        player.setRepeatMode(loopChannel ? Player.REPEAT_MODE_ONE : Player.REPEAT_MODE_OFF);
        if (!silentTune) showStatus("Loading…");
        if (loopChannel && low.contains(".m3u8") && hlsFactory != null) {
            // Smart live: open exactly at the start of the piece that is "live" now
            MediaItem item = new MediaItem.Builder().setUri(playUrl).setMimeType(MimeTypes.APPLICATION_M3U8).build();
            MediaSource ms = hlsFactory.createMediaSource(item);
            HlsInfo info = hlsInfo.get(playUrl);
            // Channel 1 (shop ad) starts from the beginning; all other own channels are live
            if (current != 0 && info != null) player.setMediaSource(ms, liveStart(info));
            else {
                player.setMediaSource(ms);
                if (info == null) loadHlsInfo(playUrl);
            }
        } else if (loopChannel && archiveFactory != null && !low.contains(".m3u8")) {  // .m3u8 = video in small pieces, uses the normal player
            MediaItem item = new MediaItem.Builder().setUri(playUrl).build();
            MediaSource ms = archiveFactory.createMediaSource(item);
            if (knownDur > 0) player.setMediaSource(ms, livePos(knownDur));
            else player.setMediaSource(ms);
        } else if (current < headers.size() && !headers.get(current).isEmpty()) {
            java.util.Map<String, String> hm = new java.util.HashMap<>(headers.get(current));
            String ua = USER_AGENT;
            for (String k : new ArrayList<>(hm.keySet())) {
                if (k.equalsIgnoreCase("User-Agent")) { ua = hm.remove(k); }
            }
            DefaultHttpDataSource.Factory hf = new DefaultHttpDataSource.Factory()
                    .setUserAgent(ua)
                    .setDefaultRequestProperties(hm)
                    .setAllowCrossProtocolRedirects(true)
                    .setConnectTimeoutMs(15000)
                    .setReadTimeoutMs(20000);
            MediaSource ms = new DefaultMediaSourceFactory(hf).createMediaSource(b.build());
            player.setMediaSource(ms);
        } else if (knownDur > 0) {
            // Open directly at the live moment: only one load, no jump afterwards
            player.setMediaItem(b.build(), livePos(knownDur));
        } else {
            player.setMediaItem(b.build());
        }
        player.prepare();
        player.play();
        updateTicker();
    }

    // Opens the same channel again with a fresh connection. Many live servers drop the
    // connection after a while; other players (like OTT Player) also reconnect quietly.
    boolean silentTune = false;

    boolean playedOk = false;   // the current channel has shown picture at least once

    // Picture frozen while the player thinks it is playing (the server jumped in time):
    // if no new picture appears for 6 seconds, quietly reopen the channel (like switching back)
    long lastFrames = -1;
    int frozenMs = 0;
    final Runnable freezeWatch = new Runnable() {
        @Override public void run() {
            try {
                if (player != null && playedOk && !blockedNow
                        && player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady()) {
                    androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
                    if (dc != null) {
                        dc.ensureUpdated();
                        long frames = dc.renderedOutputBufferCount;
                        if (frames == lastFrames) frozenMs += 2000; else frozenMs = 0;
                        lastFrames = frames;
                        if (frozenMs >= 6000) {
                            frozenMs = 0;
                            lastFrames = -1;
                            midTries = 0;
                            midReconnect();
                        }
                    }
                } else {
                    frozenMs = 0;
                    lastFrames = -1;
                }
            } catch (Throwable ignored) { }
            h.postDelayed(this, 2000);
        }
    };
    int midTries = 0;

    final Runnable stallCheck = () -> {
        if (player != null && player.getPlaybackState() == Player.STATE_BUFFERING && playedOk) {
            if (!midReconnect()) showStatus("This channel isn't available right now. Try another one.");
        }
    };

    // Reopen the same channel quietly, only if it was already playing (max 3 times per freeze)
    boolean midReconnect() {
        if (!playedOk || current < 0 || blockedNow || player == null || midTries >= 3) return false;
        midTries++;
        final int tries = midTries;
        final int ch = current;
        h.post(() -> {
            if (current != ch || blockedNow || player == null) return;
            silentTune = true;
            tune(ch);
            silentTune = false;
            playedOk = true;     // keep allowing quiet reopen while it recovers
            midTries = tries;
        });
        return true;
    }

    boolean reconnect() {
        if (true) return false;   // reconnect feature removed (as requested)
        if (current < 0 || blockedNow || retries >= 6) return false;
        retries++;
        final int ch = current;
        final int r = retries;
        h.postDelayed(() -> {
            if (current == ch && !blockedNow && player != null) {
                silentTune = true;   // reconnect quietly: no channel name, no message
                tune(ch);
                silentTune = false;
                retries = r;   // keep counting until the channel plays again
            }
        }, Math.min(1000L * r, 4000L));
        return true;
    }

    boolean isTvDevice() {
        try {
            android.app.UiModeManager ui = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (ui != null && ui.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) return true;
            android.content.pm.PackageManager pm = getPackageManager();
            if (pm.hasSystemFeature("android.software.leanback")) return true;
            if (!pm.hasSystemFeature("android.hardware.touchscreen")) return true;   // TV boxes have no touch screen
        } catch (Throwable ignored) { }
        return false;
    }

    // ---------- Web page channels (like "URL" in other IPTV apps) ----------

    final java.util.Map<String, String[]> webFound = new java.util.HashMap<>();
    android.webkit.WebView webGrabber;
    String webPending;
    boolean webRetried = false;
    final Runnable webTimeout = () -> {
        stopGrabber();
        showStatus("This channel isn't available right now. Try another one.");
    };
    final Runnable webPoke = new Runnable() {
        @Override public void run() {
            if (webGrabber == null) return;
            // start the page's video player (muted), so it asks for its video link
            webGrabber.evaluateJavascript("(function(){var v=document.querySelectorAll('video');"
                    + "for(var i=0;i<v.length;i++){try{v[i].muted=true;v[i].play();}catch(e){}}"
                    + "var s=[];for(var i=0;i<v.length;i++){s.push(v[i].currentSrc||v[i].src||'');}"
                    + "return s.join(' ');})()", res -> {
                if (res == null) return;
                for (String part : res.replace("\"", "").split(" ")) {
                    if (part.startsWith("http") && part.contains(".m3u8")) { webGot(part); return; }
                }
            });
            h.postDelayed(this, 2000);
        }
    };

    String webUserAgent() {
        try {
            return android.webkit.WebSettings.getDefaultUserAgent(this).replace("; wv", "");
        } catch (Throwable t) {
            return "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";
        }
    }

    void grabWeb(String page, int ch) {
        stopGrabber();
        webPending = page;
        try {
            android.webkit.WebView wv = new android.webkit.WebView(this);
            android.webkit.WebSettings ws = wv.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(true);
            ws.setMediaPlaybackRequiresUserGesture(false);
            ws.setUserAgentString(webUserAgent());
            wv.setWebViewClient(new android.webkit.WebViewClient() {
                @Override
                public android.webkit.WebResourceResponse shouldInterceptRequest(android.webkit.WebView v,
                        android.webkit.WebResourceRequest r) {
                    String u = r.getUrl().toString();
                    if (u.contains(".m3u8")) runOnUiThread(() -> webGot(u));
                    return null;
                }
            });
            wv.setAlpha(0.01f);
            ((ViewGroup) playerView.getParent()).addView(wv, 0, new FrameLayout.LayoutParams(2, 2));
            webGrabber = wv;
            wv.loadUrl(page);
            h.postDelayed(webPoke, 3000);
            h.postDelayed(webTimeout, 25000);
        } catch (Throwable t) {
            stopGrabber();
            showStatus("This channel isn't available right now. Try another one.");
        }
    }

    void webGot(String m3u8) {
        if (webGrabber == null || webPending == null) return;
        String page = webPending;
        webFound.put(page, new String[]{m3u8, String.valueOf(System.currentTimeMillis())});
        stopGrabber();
        playWeb(page, m3u8);
    }

    void stopGrabber() {
        h.removeCallbacks(webTimeout);
        h.removeCallbacks(webPoke);
        webPending = null;
        if (webGrabber != null) {
            try {
                webGrabber.stopLoading();
                ((ViewGroup) webGrabber.getParent()).removeView(webGrabber);
                webGrabber.destroy();
            } catch (Throwable ignored) { }
            webGrabber = null;
        }
    }

    void playWeb(String page, String m3u8) {
        java.util.Map<String, String> hm = new java.util.HashMap<>();
        hm.put("Referer", page);
        try {
            Uri pu = Uri.parse(page);
            hm.put("Origin", pu.getScheme() + "://" + pu.getHost());
        } catch (Exception ignored) { }
        DefaultHttpDataSource.Factory hf = new DefaultHttpDataSource.Factory()
                .setUserAgent(webUserAgent())
                .setDefaultRequestProperties(hm)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        MediaItem item = new MediaItem.Builder().setUri(m3u8).setMimeType(MimeTypes.APPLICATION_M3U8).build();
        player.setMediaSource(new DefaultMediaSourceFactory(hf).createMediaSource(item));
        player.prepare();
        player.play();
    }

    String cleanUrl(String u) {
        return u == null ? null : u.replace("#noticker", "");
    }

    boolean isOwnHls(String u) {
        return u != null && isLoopChannel(u) && u.toLowerCase().contains(".m3u8");
    }

    // Read the list of pieces (start time and link of each piece) once, in the background
    void loadHlsInfo(String playUrl) {
        if (playUrl == null || hlsInfo.containsKey(playUrl)) return;
        new Thread(() -> {
            String text = download(playUrl);
            if (text == null) return;
            java.util.ArrayList<Long> durs = new java.util.ArrayList<>();
            java.util.ArrayList<String> us = new java.util.ArrayList<>();
            double pending = -1;
            for (String line : text.split("\n")) {
                line = line.trim();
                if (line.startsWith("#EXTINF:")) {
                    try {
                        String v = line.substring(8);
                        int comma = v.indexOf(',');
                        pending = Double.parseDouble(comma >= 0 ? v.substring(0, comma) : v);
                    } catch (Exception e) { pending = -1; }
                } else if (!line.isEmpty() && !line.startsWith("#") && pending >= 0) {
                    String abs;
                    try { abs = new URL(new URL(playUrl), line).toString(); } catch (Exception e) { abs = line; }
                    durs.add((long) (pending * 1000));
                    us.add(abs);
                    pending = -1;
                }
            }
            if (us.isEmpty()) return;
            HlsInfo info = new HlsInfo();
            int n = us.size();
            info.startMs = new long[n];
            info.durMs = new long[n];
            info.uris = us.toArray(new String[0]);
            long t = 0;
            for (int k = 0; k < n; k++) { info.startMs[k] = t; info.durMs[k] = durs.get(k); t += durs.get(k); }
            info.totalMs = t;
            if (t > 0) hlsInfo.put(playUrl, info);
        }).start();
    }

    int liveIndex(HlsInfo info) {
        long t = System.currentTimeMillis() % info.totalMs;
        int lo = 0, hi = info.startMs.length - 1;
        while (lo < hi) {
            int mid = (lo + hi + 1) / 2;
            if (info.startMs[mid] <= t) lo = mid; else hi = mid - 1;
        }
        return lo;
    }

    // Start of the live piece (+0.1 s): the TV only needs that one piece from its beginning
    long liveStart(HlsInfo info) {
        int k = liveIndex(info);
        return k == 0 ? 0 : info.startMs[k] + 100;
    }

    // Download the live piece of the channels above and below in advance (one piece each)
    void prefetchNeighbors(int cur) {
        int n = urls.size();
        if (n < 2 || hlsCacheFactory == null) return;
        for (int d : new int[]{1, -1}) {
            String u = urls.get(((cur + d) % n + n) % n);
            if (!isOwnHls(u)) continue;
            String pu = cleanUrl(u);
            HlsInfo info = hlsInfo.get(pu);
            if (info == null) { loadHlsInfo(pu); continue; }
            int k = liveIndex(info);
            prefetchUrl(pu);
            prefetchUrl(info.uris[k]);
        }
    }

    void prefetchUrl(String u) {
        if (u == null || hlsCacheFactory == null || !prefetched.add(u)) return;
        new Thread(() -> {
            try {
                CacheWriter w = new CacheWriter(hlsCacheFactory.createDataSource(),
                        new DataSpec(Uri.parse(u)), null, null);
                w.cache();
            } catch (Throwable e) {
                prefetched.remove(u);
            }
        }).start();
    }

    // ---------- News ticker ----------

    float dp(float v) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    void setupTicker() {
        ViewGroup root = (ViewGroup) playerView.getParent();
        tickerBar = new FrameLayout(this);
        tickerBar.setBackgroundColor(Color.parseColor("#CC0E1A2B"));
        tickerBar.setClipChildren(true);
        tickerText = new TickerView(this, dp(20 * getResources().getConfiguration().fontScale), dp(6), dp(110));
        tickerBar.addView(tickerText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_VERTICAL));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        // Placed just above the video, below the channel list and other screens
        root.addView(tickerBar, root.indexOfChild(playerView) + 1, lp);

        channelLogo = new ImageView(this);
        channelLogo.setAdjustViewBounds(true);
        channelLogo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        channelLogo.setAlpha(0.9f);
        Bitmap saved = BitmapFactory.decodeFile(new File(getFilesDir(), "logo.png").getPath());
        if (saved != null) channelLogo.setImageBitmap(saved);
        else channelLogo.setImageResource(R.drawable.channel_logo);
        // Logo only, in the top-right corner (same as the first version)
        logoBox = new android.widget.LinearLayout(this);
        int size = (int) Math.min(getResources().getDisplayMetrics().heightPixels * 0.14f, dp(110));
        logoBox.addView(channelLogo, new android.widget.LinearLayout.LayoutParams(size, size));
        FrameLayout.LayoutParams llp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.END);
        llp.setMargins(0, (int) dp(20), (int) dp(24), 0);
        root.addView(logoBox, root.indexOfChild(tickerBar) + 1, llp);
        logoBox.setVisibility(View.GONE);
        tickerBar.setVisibility(View.GONE);
    }

    // If you upload logo.png to GitHub, the app uses it instead of the built-in logo
    void fetchLogo() {
        new Thread(() -> {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(LOGO_URL + "?t=" + System.currentTimeMillis()).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                Bitmap bmp = BitmapFactory.decodeStream(c.getInputStream());
                if (bmp == null) return;
                try (FileOutputStream out = new FileOutputStream(new File(getFilesDir(), "logo.png"))) {
                    bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                }
                runOnUiThread(() -> channelLogo.setImageBitmap(bmp));
            } catch (Exception ignored) {
            } finally {
                if (c != null) c.disconnect();
            }
        }).start();
    }

    void fetchTicker() {
        new Thread(() -> {
            String t = download(TICKER_URL + "?t=" + System.currentTimeMillis());
            if (t == null) return; // no internet or no file: keep what we have
            String msg = t.replace('\n', ' ').replace('\r', ' ').trim();
            if (msg.contains("<")) msg = "";
            final String m = msg;
            runOnUiThread(() -> {
                if (!m.equals(tickerMsg)) {
                    tickerMsg = m;
                    tickerText.setText(m);
                }
                updateTicker();
            });
        }).start();
    }

    void updateTicker() {
        if (tickerBar == null) return;
        boolean own = current >= 0 && current < urls.size() && isLoopChannel(urls.get(current));
        // Logo and moving text appear only after the video has started, so they never slow down loading
        boolean playing = player != null && player.getPlaybackState() == Player.STATE_READY;
        boolean showLogo = own && playing && !blockedNow;
        if (logoBox != null) logoBox.setVisibility(showLogo ? View.VISIBLE : View.GONE);
        // Channel 1 (your shop ad) never shows the moving text; all your other own channels do
        boolean show = showLogo && !tickerMsg.isEmpty() && current != 0 && !noTicker(urls.get(current));
        tickerBar.setVisibility(show ? View.VISIBLE : View.GONE);
        tickerText.setRunning(show);
    }

    // Adds the built-in sound decoder (FFmpeg) first, then the normal sound and picture players
    static class SoundDecoderRenderersFactory extends DefaultRenderersFactory {
        SoundDecoderRenderersFactory(android.content.Context c) { super(c); }

        @Override
        protected void buildAudioRenderers(android.content.Context context, int extensionRendererMode,
                androidx.media3.exoplayer.mediacodec.MediaCodecSelector mediaCodecSelector,
                boolean enableDecoderFallback, androidx.media3.exoplayer.audio.AudioSink audioSink,
                android.os.Handler eventHandler,
                androidx.media3.exoplayer.audio.AudioRendererEventListener eventListener,
                java.util.ArrayList<androidx.media3.exoplayer.Renderer> out) {
            try {
                out.add(new androidx.media3.decoder.ffmpeg.FfmpegAudioRenderer(eventHandler, eventListener, audioSink));
            } catch (Throwable ignored) { }
            super.buildAudioRenderers(context, EXTENSION_RENDERER_MODE_OFF, mediaCodecSelector,
                    enableDecoderFallback, audioSink, eventHandler, eventListener, out);
        }
    }

    // Light-weight moving text: draws only the text, no big animated view
    static class TickerView extends View {
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final float pad, speed;
        String text = "";
        float textW, x;
        boolean rtl, running, needReset = true;
        long last;

        TickerView(android.content.Context c, float textPx, float pad, float speedPxPerSec) {
            super(c);
            this.pad = pad;
            this.speed = speedPxPerSec;
            p.setColor(Color.WHITE);
            p.setTextSize(textPx);
            p.setTypeface(Typeface.DEFAULT_BOLD);
        }

        void setText(String t) {
            text = t == null ? "" : t;
            textW = p.measureText(text);
            // Kurdish/Arabic text moves left-to-right, English text moves right-to-left
            rtl = text.matches(".*[\\u0600-\\u06FF\\u0750-\\u077F\\uFB50-\\uFEFF].*");
            needReset = true;
            invalidate();
        }

        // Its own steady timer keeps the text moving, even if the TV box is busy for a moment
        final Runnable tick = new Runnable() {
            @Override public void run() {
                if (!running) return;
                invalidate();
                postOnAnimation(this);
            }
        };

        void setRunning(boolean r) {
            running = r;
            removeCallbacks(tick);
            if (r) post(tick);
        }

        @Override
        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (running) { removeCallbacks(tick); post(tick); }
        }

        @Override
        protected void onWindowVisibilityChanged(int v) {
            super.onWindowVisibilityChanged(v);
            if (v == VISIBLE && running) { removeCallbacks(tick); last = 0; post(tick); }
        }

        @Override
        protected void onVisibilityChanged(View changed, int v) {
            super.onVisibilityChanged(changed, v);
            if (v == VISIBLE && running) { removeCallbacks(tick); last = 0; post(tick); }
        }

        @Override
        protected void onMeasure(int w, int h) {
            android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            int height = (int) Math.ceil(fm.descent - fm.ascent + pad * 2);
            setMeasuredDimension(MeasureSpec.getSize(w), height);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            needReset = true;
        }

        @Override
        protected void onDraw(android.graphics.Canvas c) {
            if (text.isEmpty() || getWidth() == 0) return;
            if (needReset) {
                x = rtl ? -textW : getWidth();
                needReset = false;
                last = 0;
            }
            long now = android.os.SystemClock.uptimeMillis();
            if (running && last != 0) {
                long dt = Math.min(now - last, 100); // after a short freeze, continue smoothly instead of jumping
                float dx = speed * dt / 1000f;
                x += rtl ? dx : -dx;
                if (!rtl && x < -textW) x = getWidth();
                if (rtl && x > getWidth()) x = -textW;
            }
            last = now;
            android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            float y = getHeight() / 2f - (fm.ascent + fm.descent) / 2f;
            c.drawText(text, x, y, p);
        }
    }


    String finalKey(String url) {
        return "fin_" + url.hashCode();
    }

    // Archive.org links first jump (redirect) to the real server. Find that server once
    // and save it, so next time the video opens without the extra jump.
    void resolveArchive(String url) {
        new Thread(() -> {
            try {
                String u = url;
                for (int hop = 0; hop < 6; hop++) {
                    HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
                    c.setInstanceFollowRedirects(false);
                    c.setRequestMethod("HEAD");
                    c.setRequestProperty("User-Agent", USER_AGENT);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(15000);
                    int code = c.getResponseCode();
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (code >= 300 && code < 400 && loc != null) {
                        u = new URL(new URL(u), loc).toString();
                        continue;
                    }
                    if (code >= 200 && code < 300 && !u.equals(url)) {
                        prefs.edit().putString(finalKey(url), u).apply();
                    }
                    return;
                }
            } catch (Exception ignored) {
            }
        }).start();
    }

    // Videos hosted on Archive.org play like a live channel (continue + loop)
    // Channels without the moving text: your shop ad channel, or any link ending with #noticker
    boolean noTicker(String url) {
        if (url == null) return false;
        return url.contains("#noticker") || url.contains("VID_20260919_031449_288");
    }

    // The live moment, moved to just after the start of the 30-second video piece it falls in.
    // The TV then only downloads a few seconds of that piece before playing, so it opens fast.
    long livePos(long dur) {
        long t = System.currentTimeMillis() % dur;
        long a = (t / 30000L) * 30000L + 6000L;
        return a < dur ? a : t;
    }

    String durKey(String url) {
        return "dur_" + url.hashCode();
    }

    boolean isLoopChannel(String url) {
        if (url == null) return false;
        String u = url.toLowerCase();
        // Your own channels: videos on Archive.org, or fixed videos in your GitHub "videos" release
        return u.contains("archive.org") || u.contains("/releases/download/videos/");
    }

    void showStatus(String text) {
        status.setText(text);
        status.setVisibility(View.VISIBLE);
    }

    // ---------- Channel guide ----------

    void openGuide() {
        if (urls.isEmpty()) return;
        guide.setVisibility(View.VISIBLE);
        list.requestFocus();
        int pos = Math.max(current, 0);
        list.setSelection(pos);
        list.setItemChecked(pos, true);
        resetGuideTimer();
    }

    void closeGuide() {
        guide.setVisibility(View.GONE);
        h.removeCallbacks(hideGuide);
        hideSystemUi();
    }

    void resetGuideTimer() {
        h.removeCallbacks(hideGuide);
        if (guide.getVisibility() == View.VISIBLE) h.postDelayed(hideGuide, 12000);
    }

    // ---------- Remote control ----------

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (crashScreen) return super.dispatchKeyEvent(e);
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
        if (blockedNow && k != KeyEvent.KEYCODE_BACK && k != KeyEvent.KEYCODE_HOME) return true;

        if (act.getVisibility() == View.VISIBLE) {
            if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_0));
                return true;
            }
            if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_NUMPAD_0));
                return true;
            }
            if (k == KeyEvent.KEYCODE_DEL) {
                if (down) press("del");
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        boolean center = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (swallowCenterUp && center && !down) {
            swallowCenterUp = false;
            return true;
        }

        // Menu button: in the channel list -> channel menu; while watching -> search
        if (k == KeyEvent.KEYCODE_MENU) {
            if (down && e.getRepeatCount() == 0) {
                if (guide.getVisibility() == View.VISIBLE) {
                    int p = list.getSelectedItemPosition();
                    channelMenu(p >= 0 ? p : Math.max(current, 0));
                }
            }
            return true;
        }

        if (guide.getVisibility() == View.VISIBLE) {
            resetGuideTimer();
            if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
                if (down) closeGuide();
                return true;
            }
            // In the channel list the highlight moves normally. Only:
            // Up on the first channel -> last, Down on the last -> first,
            // Left/Right (and CH-/CH+) jump 10 channels. The list never jumps around.
            int n = list.getCount();
            int pos = list.getSelectedItemPosition();
            if (pos < 0) pos = Math.max(current, 0);
            boolean jump = k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT
                    || k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_CHANNEL_DOWN
                    || k == KeyEvent.KEYCODE_PAGE_UP || k == KeyEvent.KEYCODE_PAGE_DOWN;
            boolean wrapUp = k == KeyEvent.KEYCODE_DPAD_UP && pos == 0;
            boolean wrapDown = k == KeyEvent.KEYCODE_DPAD_DOWN && pos == n - 1;
            if (n > 0 && (jump || wrapUp || wrapDown)) {
                if (!down) return true;
                int target;
                if (wrapUp) target = n - 1;
                else if (wrapDown) target = 0;
                else {
                    int step = (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_CHANNEL_DOWN
                            || k == KeyEvent.KEYCODE_PAGE_UP) ? -10 : 10;
                    target = pos + step;
                    if (target < 0) target = (pos == 0) ? n - 1 : 0;
                    else if (target > n - 1) target = (pos == n - 1) ? 0 : n - 1;
                }
                View first = list.getChildAt(0);
                int itemH = first != null ? first.getHeight() : 0;
                int top;
                if (jump) top = 0;                                          // Left/Right: channel at the top of the list
                else if (wrapUp) top = Math.max(0, list.getHeight() - itemH); // last channel shown at the bottom
                else top = 0;
                list.requestFocus();
                list.setSelectionFromTop(target, top);
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        // Volume: Right = louder, Left = quieter (holding the button keeps changing it)
        if (k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_LEFT) {
            if (down) {
                AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
                if (am != null) am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                        k == KeyEvent.KEYCODE_DPAD_RIGHT ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI);
            }
            return true;
        }

        // Number buttons: type the channel number, like a satellite receiver
        int digit = -1;
        if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) digit = k - KeyEvent.KEYCODE_0;
        else if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) digit = k - KeyEvent.KEYCODE_NUMPAD_0;
        if (digit >= 0) {
            if (down && e.getRepeatCount() == 0) typeDigit(digit);
            return true;
        }

        boolean next = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP;
        boolean prev = k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN;
        if (next || prev || center) {
            if (down && e.getRepeatCount() == 0) {
                if (next) tune(current < 0 ? 0 : current + 1);
                else if (prev) tune(current < 0 ? 0 : current - 1);
                else {
                    swallowCenterUp = true;
                    openGuide();
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    void typeDigit(int d) {
        if (urls.isEmpty()) return;
        if (numBuf.length() >= 4) numBuf = "";
        numBuf += d;
        osd.setText(numBuf + " _");
        osd.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideOsd);
        h.removeCallbacks(numGo);
        // Enough digits for the highest channel number: open now, otherwise wait 2 seconds
        if (numBuf.length() >= String.valueOf(urls.size()).length()) h.postDelayed(numGo, 300);
        else h.postDelayed(numGo, 2000);
    }

    void goNumber() {
        String b = numBuf;
        numBuf = "";
        if (b.isEmpty()) return;
        int n;
        try { n = Integer.parseInt(b); } catch (Exception ex) { return; }
        if (n >= 1 && n <= urls.size()) {
            tune(n - 1);
        } else {
            osd.setText(b + "   No channel");
            osd.setVisibility(View.VISIBLE);
            h.removeCallbacks(hideOsd);
            h.postDelayed(hideOsd, 2000);
        }
    }

    // ---------- Automatic update from GitHub Releases ----------

    int myVersion() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception ex) {
            return Integer.MAX_VALUE;
        }
    }

    void checkUpdate() {
        new Thread(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(RELEASE_API).openConnection();
                c.setRequestProperty("User-Agent", "MohammedTV");
                c.setRequestProperty("Accept", "application/vnd.github+json");
                c.setConnectTimeout(15000);
                c.setReadTimeout(20000);
                if (c.getResponseCode() != 200) return;
                StringBuilder sb = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) sb.append(line);
                }
                JSONObject rel = new JSONObject(sb.toString());
                int latest = Integer.parseInt(rel.optString("tag_name", "v0").replaceAll("[^0-9]", "0").replaceFirst("^0+(?=.)", ""));
                if (latest <= myVersion()) return;
                String apkUrl = null;
                JSONArray assets = rel.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject a = assets.getJSONObject(i);
                        if (a.optString("name").toLowerCase().endsWith(".apk")) {
                            apkUrl = a.optString("browser_download_url");
                            break;
                        }
                    }
                }
                if (apkUrl == null) return;
                final String u = apkUrl;
                runOnUiThread(() -> askUpdate(u));
            } catch (Exception ignored) {
            }
        }).start();
    }

    void askUpdate(String apkUrl) {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
                .setTitle("New update available")
                .setMessage("A new version of Mohammed TV is ready. Update now?")
                .setPositiveButton("Update", (d, w) -> downloadUpdate(apkUrl))
                .setNegativeButton("Later", null)
                .show();
    }

    void downloadUpdate(String apkUrl) {
        AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("Updating Mohammed TV")
                .setMessage("Downloading… 0%")
                .setCancelable(false)
                .show();
        new Thread(() -> {
            File dir = getExternalCacheDir() != null ? getExternalCacheDir() : getCacheDir();
            File f = new File(dir, "MohammedTV-update.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(apkUrl).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "MohammedTV");
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                int total = c.getContentLength();
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(f)) {
                    byte[] buf = new byte[16384];
                    long got = 0;
                    int n, lastPct = -1;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        if (total > 0) {
                            int pct = (int) (got * 100 / total);
                            if (pct != lastPct) {
                                lastPct = pct;
                                runOnUiThread(() -> progress.setMessage("Downloading… " + pct + "%"));
                            }
                        }
                    }
                }
                runOnUiThread(() -> {
                    progress.dismiss();
                    installApk(f);
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    progress.dismiss();
                    new AlertDialog.Builder(this)
                            .setMessage("The update couldn't be downloaded. Check your internet and try again later.")
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        }).start();
    }

    boolean canInstall() {
        return Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    void installApk(File f) {
        if (!canInstall()) {
            // Android 8+: the user must allow this app to install updates (only once)
            pendingApk = f;
            new AlertDialog.Builder(this)
                    .setTitle("One-time permission")
                    .setMessage("To install the update, turn on \"Allow from this source\" for Mohammed TV on the next screen, then come back.")
                    .setPositiveButton("OK", (d, w) -> {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Exception ex) {
                            try { startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS)); } catch (Exception ignored) { }
                        }
                    })
                    .show();
            return;
        }
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            Uri uri;
            if (Build.VERSION.SDK_INT >= 24) {
                uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } else {
                uri = Uri.fromFile(f);
            }
            i.setDataAndType(uri, "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ex) {
            new AlertDialog.Builder(this)
                    .setMessage("The update couldn't be opened on this device.")
                    .setPositiveButton("OK", null)
                    .show();
        }
    }

    // ---------- Protection: no VPN, no proxy, no sniffing apps ----------

    String securityProblem() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= 23) {
                for (Network n : cm.getAllNetworks()) {
                    NetworkCapabilities c = cm.getNetworkCapabilities(n);
                    if (c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                        return "Please turn off your VPN to watch Mohammed TV.";
                    }
                }
            }
        } catch (Exception ignored) { }
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                String name = ni.getName();
                if (ni.isUp() && (name.startsWith("tun") || name.startsWith("ppp") || name.startsWith("tap"))) {
                    return "Please turn off your VPN to watch Mohammed TV.";
                }
            }
        } catch (Exception ignored) { }
        String proxy = System.getProperty("http.proxyHost");
        if (proxy != null && !proxy.trim().isEmpty()) {
            return "Please turn off the proxy in your Wi-Fi settings to watch Mohammed TV.";
        }
        PackageManager pm = getPackageManager();
        for (String pkg : SNIFFERS) {
            try {
                pm.getPackageInfo(pkg, 0);
                return "A network capture app is installed on this device.\nUninstall it to watch Mohammed TV.";
            } catch (Exception ignored) { }
        }
        return null;
    }

    volatile boolean guardRunning = false;

    void guard() {
        if (guardRunning) return;
        guardRunning = true;
        new Thread(() -> {
            String problem = null;
            try { problem = securityProblem(); } catch (Throwable ignored) { }
            final String p = problem;
            runOnUiThread(() -> {
                guardRunning = false;
                if (!isFinishing()) applyGuard(p);
            });
        }).start();
    }

    void applyGuard(String problem) {
        if (problem != null) {
            if (player != null) player.stop();
            blocker.setText(problem);
            blocker.setVisibility(View.VISIBLE);
            blockedNow = true;
        } else if (blockedNow) {
            blockedNow = false;
            blocker.setVisibility(View.GONE);
            if (prefs.getBoolean("activated", false)) {
                if (urls.isEmpty()) start();
                else tune(Math.max(current, 0));
            }
        }
    }

    // ---------- Screen / lifecycle ----------

    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (crashScreen) return;
        h.removeCallbacks(guardLoop);
        h.postDelayed(guardLoop, 4000);
        h.removeCallbacks(freezeWatch);
        h.postDelayed(freezeWatch, 2000);
        guard();
        if (pendingApk != null && canInstall()) {
            File f = pendingApk;
            pendingApk = null;
            installApk(f);
        }
        if (player != null && current >= 0 && !blockedNow) {
            HlsInfo info = (current < urls.size() && isOwnHls(urls.get(current)))
                    ? hlsInfo.get(cleanUrl(urls.get(current))) : null;
            if (current != 0 && info != null) player.seekTo(liveStart(info)); // live (not channel 1)
            else player.seekToDefaultPosition();
            player.prepare();
            player.play();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (crashScreen) return;
        stopGrabber();
        h.removeCallbacks(guardLoop);
        h.removeCallbacks(freezeWatch);
        if (player != null) player.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
        if (mediaCache != null) {
            try { mediaCache.release(); } catch (Throwable ignored) { }
            mediaCache = null;
        }
    }

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
