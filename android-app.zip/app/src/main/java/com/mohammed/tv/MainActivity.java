package com.mohammed.tv;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    static final String PLAYLIST_URL = "https://raw.githubusercontent.com/k19848781-eng/Mohammed/main/playlist.m3u";
    static final String USER_AGENT = "VLC/3.0.20 LibVLC/3.0.20";
    static final String ACTIVATION_CODE = "1010";

    SharedPreferences prefs;
    ExoPlayer player;
    PlayerView playerView;
    TextView osd, status, dots, msg;
    View guide, act, tap;
    ListView list;
    ArrayAdapter<String> adapter;

    final List<String> names = new ArrayList<>();
    final List<String> urls = new ArrayList<>();
    final List<String> labels = new ArrayList<>();
    final List<Button> keys = new ArrayList<>();

    int current = -1;
    int retries = 0;
    String code = "";
    boolean swallowCenterUp = false;

    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable hideOsd = () -> osd.setVisibility(View.GONE);
    final Runnable hideGuide = this::closeGuide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();

        prefs = getSharedPreferences("mtv", MODE_PRIVATE);
        playerView = findViewById(R.id.player);
        osd = findViewById(R.id.osd);
        status = findViewById(R.id.status);
        guide = findViewById(R.id.guide);
        list = findViewById(R.id.list);
        act = findViewById(R.id.act);
        dots = findViewById(R.id.dots);
        msg = findViewById(R.id.msg);
        tap = findViewById(R.id.tap);

        // Player that behaves like VLC: any link, http or https, with a VLC user agent
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(USER_AGENT)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        DefaultDataSource.Factory dataSource = new DefaultDataSource.Factory(this, http);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataSource))
                .build();
        playerView.setPlayer(player);
        playerView.setUseController(false);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setKeepScreenOn(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    retries = 0;
                    status.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    showStatus("Loading…");
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (retries < 3) {
                    retries++;
                    showStatus("Reconnecting…");
                    final int ch = current;
                    h.postDelayed(() -> {
                        if (ch == current) {
                            player.prepare();
                            player.play();
                        }
                    }, 2000);
                } else {
                    showStatus("This channel isn't available right now. Try another one.");
                }
            }
        });

        adapter = new ArrayAdapter<>(this, R.layout.item_channel, labels);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            tune(position);
            closeGuide();
        });
        list.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView v, int s) { resetGuideTimer(); }
            @Override public void onScroll(android.widget.AbsListView v, int a, int b, int c) { }
        });

        tap.setOnClickListener(v -> {
            if (guide.getVisibility() == View.VISIBLE) closeGuide();
            else openGuide();
        });

        buildKeypad();

        if (prefs.getBoolean("activated", false)) {
            start();
        } else {
            act.setVisibility(View.VISIBLE);
            drawCode();
            if (!keys.isEmpty()) keys.get(0).requestFocus();
        }
    }

    // ---------- Activation ----------

    void buildKeypad() {
        GridLayout pad = findViewById(R.id.pad);
        String[] labelsArr = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK"};
        int size = dp(76);
        int gap = dp(6);
        for (String k : labelsArr) {
            Button b = new Button(this);
            b.setText(k);
            b.setAllCaps(false);
            b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
            b.setTypeface(Typeface.DEFAULT_BOLD);
            b.setGravity(Gravity.CENTER);
            b.setFocusable(true);
            b.setBackgroundResource(R.drawable.key_bg);
            b.setTextColor(k.equals("OK") ? 0xFFF5B83D : 0xFFEAF1F8);
            b.setStateListAnimator(null);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = (int) (size * 1.25);
            lp.height = size;
            lp.setMargins(gap, gap, gap, gap);
            b.setLayoutParams(lp);
            final String key = k.equals("⌫") ? "del" : k.equals("OK") ? "ok" : k;
            b.setOnClickListener(v -> press(key));
            pad.addView(b);
            keys.add(b);
        }
    }

    void press(String k) {
        msg.setText("");
        if (k.equals("del")) {
            if (code.length() > 0) code = code.substring(0, code.length() - 1);
        } else if (k.equals("ok")) {
            check();
            return;
        } else if (code.length() < 4) {
            code += k;
            if (code.length() == 4) {
                drawCode();
                h.postDelayed(this::check, 250);
                return;
            }
        }
        drawCode();
    }

    void check() {
        if (code.equals(ACTIVATION_CODE)) {
            prefs.edit().putBoolean("activated", true).apply();
            act.setVisibility(View.GONE);
            start();
        } else {
            msg.setText("Wrong code. Try again.");
            code = "";
            drawCode();
        }
    }

    void drawCode() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) {
            sb.append(i < code.length() ? "●" : "○");
            if (i < 3) sb.append(' ');
        }
        dots.setText(sb.toString());
    }

    // ---------- Playlist ----------

    void start() {
        String cached = prefs.getString("playlist", null);
        if (cached != null) {
            parse(cached);
            if (!urls.isEmpty()) tune(0);
        }
        if (urls.isEmpty()) showStatus("Loading channels…");
        new Thread(() -> {
            String text = download(PLAYLIST_URL + "?t=" + System.currentTimeMillis());
            if (text == null || !text.contains("#EXT")) {
                h.post(() -> { if (urls.isEmpty()) showStatus("Can't load channels. Check the internet."); });
                return;
            }
            h.post(() -> {
                prefs.edit().putString("playlist", text).apply();
                parse(text);
                if (current < 0 || current >= urls.size()) {
                    if (!urls.isEmpty()) tune(0);
                }
            });
        }).start();
    }

    String download(String address) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return null;
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    void parse(String text) {
        names.clear();
        urls.clear();
        labels.clear();
        String name = null;
        for (String raw : text.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                int comma = line.lastIndexOf(',');
                name = comma >= 0 ? line.substring(comma + 1).trim() : null;
            } else if (!line.startsWith("#")) {
                String n = (name == null || name.isEmpty()) ? "Channel " + (urls.size() + 1) : name;
                names.add(n);
                urls.add(line);
                labels.add((urls.size()) + "    " + n);
                name = null;
            }
        }
        adapter.notifyDataSetChanged();
        if (current >= 0 && current < urls.size()) list.setItemChecked(current, true);
    }

    // ---------- Playback ----------

    void tune(int i) {
        int n = urls.size();
        if (n == 0) return;
        current = ((i % n) + n) % n;
        retries = 0;
        String url = urls.get(current);
        osd.setText((current + 1) + "   " + names.get(current));
        osd.setVisibility(View.VISIBLE);
        h.removeCallbacks(hideOsd);
        h.postDelayed(hideOsd, 3500);
        list.setItemChecked(current, true);

        MediaItem.Builder b = new MediaItem.Builder().setUri(url);
        String low = url.toLowerCase();
        if (low.contains(".m3u8")) {
            b.setMimeType(MimeTypes.APPLICATION_M3U8);
        }
        showStatus("Loading…");
        player.setMediaItem(b.build());
        player.prepare();
        player.play();
    }

    void showStatus(String text) {
        status.setText(text);
        status.setVisibility(View.VISIBLE);
    }

    // ---------- Channel guide ----------

    void openGuide() {
        if (urls.isEmpty()) return;
        guide.setVisibility(View.VISIBLE);
        list.requestFocus();
        int pos = Math.max(current, 0);
        list.setSelection(pos);
        list.setItemChecked(pos, true);
        resetGuideTimer();
    }

    void closeGuide() {
        guide.setVisibility(View.GONE);
        h.removeCallbacks(hideGuide);
        hideSystemUi();
    }

    void resetGuideTimer() {
        h.removeCallbacks(hideGuide);
        if (guide.getVisibility() == View.VISIBLE) h.postDelayed(hideGuide, 12000);
    }

    // ---------- Remote control ----------

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (act.getVisibility() == View.VISIBLE) {
            if (k >= KeyEvent.KEYCODE_0 && k <= KeyEvent.KEYCODE_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_0));
                return true;
            }
            if (k >= KeyEvent.KEYCODE_NUMPAD_0 && k <= KeyEvent.KEYCODE_NUMPAD_9) {
                if (down) press(String.valueOf(k - KeyEvent.KEYCODE_NUMPAD_0));
                return true;
            }
            if (k == KeyEvent.KEYCODE_DEL) {
                if (down) press("del");
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        boolean center = k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_NUMPAD_ENTER;
        if (swallowCenterUp && center && !down) {
            swallowCenterUp = false;
            return true;
        }

        if (guide.getVisibility() == View.VISIBLE) {
            resetGuideTimer();
            if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_ESCAPE) {
                if (down) closeGuide();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        boolean next = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_PAGE_UP;
        boolean prev = k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_PAGE_DOWN;
        if (next || prev || center) {
            if (down && e.getRepeatCount() == 0) {
                if (next) tune(current < 0 ? 0 : current + 1);
                else if (prev) tune(current < 0 ? 0 : current - 1);
                else {
                    swallowCenterUp = true;
                    openGuide();
                }
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }

    // ---------- Screen / lifecycle ----------

    void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (player != null && current >= 0) {
            player.seekToDefaultPosition();
            player.prepare();
            player.play();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.stop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        h.removeCallbacksAndMessages(null);
        if (player != null) {
            player.release();
            player = null;
        }
    }

    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
